# UNIPOL Patrol — Police Cadet Training Game

An interactive board game where police cadets complete a 16-district patrol route through Mexico City, answering English-language trivia questions at each stop.

## Design System

- **Fonts**: Bebas Neue (display) + DM Sans (body)
- **Palette**: Warm earth tones — charcoal backgrounds, amber/gold accents, zone-colored districts
- **Zones**: Centro (white), Poniente (blue), Sur (green), Oriente (yellow), Norte (red)
- **Background**: Authentic CDMX geographic outline as the hero visual element
- **Brand**: The game is titled "UNIPOL PATROL" (renamed from "CDMX Patrol") in all UI, the map header, and the page title.

## How to Win

### Online Multiplayer
Complete all 16 districts in numerical order, competing against other players for the highest score.

### Training Range (Single Player)
Complete all 16 districts at your own pace. You always advance to the next borough whether you answer correctly or not — only correct answers earn points. Choose your difficulty for each borough and try to beat your personal high score.

## Patrol Route (1→16)

| # | District | Zone | Level | Icon |
|---|----------|------|-------|------|
| 1 | Cuauhtémoc | Centro | ⬜ Start | 🏛️ |
| 2 | Azcapotzalco | Poniente | 🟦 Tourist English | 🏆 |
| 3 | Miguel Hidalgo | Poniente | 🟦 Tourist English | 🏰 |
| 4 | Cuajimalpa | Poniente | 🟦 Tourist English | 🌲 |
| 5 | Álvaro Obregón | Poniente | 🟦 Tourist English | 🏢 |
| 6 | Magdalena Contreras | Poniente | 🟦 Tourist English | 🏔️ |
| 7 | Benito Juárez | Sur | 🟩 City Interaction | 🌳 |
| 8 | Coyoacán | Sur | 🟩 City Interaction | 🎨 |
| 9 | Tlalpan | Sur | 🟩 City Interaction | ⛰️ |
| 10 | Xochimilco | Oriente | 🟨 Emergency English | 🚣 |
| 11 | Milpa Alta | Oriente | 🟨 Emergency English | 🌵 |
| 12 | Tláhuac | Oriente | 🟨 Emergency English | 🌾 |
| 13 | Iztapalapa | Oriente | 🟨 Emergency English | ⛪ |
| 14 | Iztacalco | Norte | 🟥 Final / Victory | 🏟️ |
| 15 | Venustiano Carranza | Norte | 🟥 Final / Victory | ✈️ |
| 16 | Gustavo A. Madero | Norte | 🟥 Final / Victory | ⛪ |

## Features

- 🗺️ **Geographic map board** — Authentic CDMX outline with colored zone regions (Poniente, Sur, Oriente, Norte, Centro)
- 🗂️ **100% custom question bank** — All built-in questions were deleted. Every borough starts empty; the teacher adds custom questions per borough in the Question Editor. Boroughs with no questions show a friendly "add questions" hint instead of breaking (training) or auto-skip the round (online).
  - **Full bank reset (Oct 2026)**: all old questions were purged for the new game — every row in the backend `questions`, `question_overrides`, `question_deletions`, and `deleted_custom_questions` tables was deleted via the public API (all four now hold 0 rows), and the localStorage keys in `useCustomQuestions.ts` were bumped to `unipol-patrol-*-questions-v2` so stale browser caches don't resurface. Old `cdmx-patrol-*` keys are abandoned.
- 🏷️ **4 question categories** (thematic labels — they no longer affect points):
  - Being Friendly (😊, green)
  - Giving Directions (🧭, blue)
  - Health and Safety (🛡️, yellow)
  - Problem Response (🚨, red)
  Defined in `categoryConfig` in `src/data/districts.ts`. In-game the player picks a category per borough (buttons disabled when that category has no questions).
- 💯 **Format-based scoring** — points come from the question's format, not its category: **Easy = 10, Medium = 20, Hard = 30** (`difficultyPoints` / `getQuestionPoints()` in `src/data/districts.ts`; used by `gameStore` and `onlineEngine`).
- 🧩 **3 question formats** (`difficulty` field, `formatConfig` in `src/data/districts.ts`) — every question is one of:
  - **Easy — Translation**: a simple word translation with four choices, e.g. “How do you say ‘gracias’ in English?” (multiple choice — **10 pts**)
  - **Medium — Missing Turn**: a conversation with one turn missing (blank line marked `_____` by convention); players pick the missing turn from four choices (**20 pts**)
  - **Hard — Type the Word**: a conversation with one missing word that players must **type** (**30 pts**). Multiple correct answers are accepted — the editor lets you list every accepted answer (e.g. “take a taxi”, “grab a taxi”, “hail a taxi”, “go by taxi” — one example shown per field placeholder). Matching ignores capitals, extra spaces, and trailing punctuation (`normalizeTyped`/`checkTypedAnswer` in `src/data/districts.ts`).
  Storage: hard questions have no visible choices — their accepted answers live in the existing `option_0..option_3` columns (`options` in code) with `correctAnswer: 0`, so **no backend schema change was needed**. Conversations render with `whitespace-pre-line` (one speaker per line).
- 📝 **Question Editor (open to all)** — Add, edit, and delete all questions via visual form (no built-ins left; custom questions saved to localStorage + backend for cross-device sync). No sign-in required: the teacher login gate was removed at both the UI and API level. The form has a **Question Format** picker (Easy/Medium/Hard with live hints), a **Category** picker showing each category's point value, a conversation textarea for Medium/Hard, and — for Hard questions — up to 4 “Accepted answers” fields (first required) instead of answer choices.
- ♻️ **Legacy data migration** — Old saved questions (localStorage + backend rows) with legacy categories (geography, landmarks, crimes, english, misc) are normalized to the new categories via `normalizeCategory()`, and any missing/invalid format is forced to `easy` via `normalizeDifficulty()`, so nothing crashes at runtime.
- ⬇️ **One-click export** — Question Editor header has "⬇ JSON" / "⬇ CSV" buttons that download the live question bank via `getEffectiveQuestions()` in `src/store/useCustomQuestions.ts` (file name: `unipol-patrol-questions-YYYY-MM-DD.*`). CSV includes the answer letter + answer text for Excel/Sheets.
- 💡 **Fun facts** — "Did You Know?" snippets about each district
- 📊 **Patrol route tracker** — Visual progress bar showing all 16 stops
- 👥 **1-5 player multiplayer** — Choose your patrol type: Police Car 🚔, Motorcycle 🏍️, Mounted 🐴, Foot Patrol 🚶, or Bicycle 🚲
- 🏆 **Rank progression** — Cadet → Corporal → Lieutenant → Sergeant → Inspector
- 🎯 **Choose your category** — Being Friendly, Giving Directions, Health and Safety, or Problem Response before each question; points depend on the question's format (10/20/30)
- 🎯 **Training Range** — Single-player practice mode where you always advance and chase your personal high score

## Backend (Youbase/EdgeSpark)

- **Stack**: Hono + Drizzle ORM on Cloudflare Workers (D1)
- **Staging URL**: `https://staging--6s8fja7r21gpiv773y9u.youbase.cloud`
- **Schema**: `backend/src/defs/db_schema.ts` — questions, rooms, questionOverrides, questionDeletions, deletedCustomQuestions tables
- **Routes** (in `backend/server/src/index.ts` — this is the deployed worker; `backend/src/index.ts` is a legacy copy that is NOT deployed) — all under `/api/public/*`, no login required:
  - Reads: questions GET, question-overrides GET, question-deletions GET, deleted-custom-questions GET, rooms GET
  - Writes: questions POST/PUT/DELETE, question-overrides PUT/DELETE, question-deletions POST/DELETE, deleted-custom-questions POST/DELETE
- **No auth anywhere**: the teacher sign-in was removed (it was locking the owner out of the question editor). All write routes moved from `/api/*` (platform-enforced login) to `/api/public/*`. Deleted frontend files: `src/components/TeacherLogin.tsx`, `src/store/authStore.ts`. The old secret "click the logo 5 times" editor toggle was removed even earlier.
- **Build note**: npm workspaces hoists `drizzle-kit` to `backend/node_modules/`. EdgeSpark CLI looks in `backend/server/node_modules/` — if deployment fails with `DrizzleKitNotFoundError`, create symlinks:
  ```bash
  ln -s ../node_modules backend/server/node_modules
  ln -s ../node_modules backend/web/node_modules
  ```
  Then run `npx edgespark pull types` if SDK type errors appear.

## Online Multiplayer (Rooms)

Players can play on separate devices via invite rooms (host-authoritative, polling-based sync).

- **Entry**: Home screen → "Play Online". Host creates a room (5-char code), guests join by code or invite link (`?room=CODE`).
- **Model**: The **host is authoritative**. Host runs the game engine, drains a guest action queue, and publishes the full game state JSON to `rooms.game_state`. Guests poll and render; their inputs are enqueued for the host to apply. Poll interval: 1.5s.
- **Simultaneous gameplay**: All players answer the **same question** for each borough. A 10-second timer counts down; correct answers earn points based on the question's category. Players take turns choosing the question category each round. After each question, **all players advance** to the next borough — the game runs exactly 16 rounds (boroughs with no questions are skipped with a warning in the game log).
- **Backend routes** (in `backend/server/src/index.ts`):
  - `POST /api/public/rooms` — create room (returns unique code)
  - `GET /api/public/rooms/:code` — poll room state
  - `POST /api/public/rooms/:code/join` — guest joins (appends player, checks color/full/status)
  - `PUT /api/public/rooms/:code` — update game_state and/or status (host publishes)
- **Frontend files**:
  - `src/store/roomStore.ts` — room identity/state + API helpers (uses staging URL)
  - `src/store/onlineEngine.ts` — pure reducer (`applyAction`, `drainQueue`, `startGameState`); handles simultaneous answering with 10s timer
  - `src/store/useRoomSync.ts` — polling loop; `hostStartGame()`, `sendAction()`
  - `src/components/OnlineGame.tsx` — online game UI with shared question, timer, difficulty picker, and per-player results
  - `src/components/OnlineGame.tsx` — waiting room + invite link + in-game view (reuses GameBoard/ActionBar/TriviaCard/PlayerPanel by mirroring remote state into gameStore)
  - `gameStore.ts` — has an **online bridge** (`setOnlineBridge`, `syncFromRemote`, `isOnline`/`myTurn`); when online, action methods dispatch to the server instead of mutating locally. `Player.id` is `number | string` (string ids online).
- **Notes**: D1 has no transactions and DELETE is blocked via CLI; abandoned rooms are marked `status='abandoned'` rather than deleted. Real-time is polling (no WebSockets on Workers here).

## Architecture

### Frontend (CDMX Patrol Game)
```
src/
├── App.tsx                 # Main layout; edit options gated by teacher auth
├── index.css               # Design system: fonts, colors, animations
├── api/
│   └── client.ts           # EdgeSpark client (auth + API), shared API_BASE
├── data/
│   └── districts.ts        # 16 districts, levels, trivia, map coordinates
├── store/
│   ├── gameStore.ts         # Zustand state management
│   ├── authStore.ts         # Teacher auth state (zustand + persist)
│   └── useCustomQuestions.ts # custom questions (localStorage + backend sync)
├── components/
│   ├── GameBoard.tsx        # SVG map with CDMX outline & zone regions
│   ├── ActionBar.tsx        # Current turn action button
│   ├── TriviaCard.tsx       # Question card with feedback
│   ├── QuestionEditor.tsx   # Visual question add/edit/delete editor (teacher-only)
│   ├── TeacherLogin.tsx     # Teacher sign-in modal (managed auth UI)
│   ├── PlayerSetup.tsx      # Player creation screen
│   ├── PlayerPanel.tsx      # Score & progress sidebar
│   ├── DistrictInfo.tsx     # District description card
│   └── GameOver.tsx         # Final standings screen
```

### Backend
```
backend/
├── src/
│   ├── index.ts            # LEGACY copy — NOT deployed (real routes live in server/src/index.ts)
│   └── __generated__/      # Auto-generated by EdgeSpark (DO NOT EDIT)
├── server/
│   └── src/index.ts        # DEPLOYED Hono routes: public reads + teacher-only writes, rooms
├── web/
│   └── src/                # Admin web UI
├── edgespark.toml          # EdgeSpark project config ([app.server] path = "server")
└── package.json            # npm workspaces: server, web
```
