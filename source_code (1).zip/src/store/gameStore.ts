import { create } from 'zustand';
import { districts, patrolRoute, getRandomQuestion, TriviaQuestion } from '../data/districts';
import { CustomQuestionStore } from './useCustomQuestions';

let customQuestionsRef: CustomQuestionStore[] = [];
let editedQuestionsRef: Record<string, { districtId: number; question: TriviaQuestion }> = {};
let deletedIdsRef: string[] = [];

export function setCustomQuestionsRef(ref: CustomQuestionStore[], edited: Record<string, { districtId: number; question: TriviaQuestion }>, deleted: string[]) {
  customQuestionsRef = ref;
  editedQuestionsRef = edited;
  deletedIdsRef = deleted;
}

export type PlayerColor = 'car' | 'moto' | 'horse' | 'foot' | 'bike';

export interface Player {
  id: number | string;
  name: string;
  color: PlayerColor;
  routeIndex: number; // 0-15, position in patrolRoute
  currentDistrictId: number;
  score: number;
  answeredQuestions: string[];
  badge: string;
}

export interface GameState {
  players: Player[];
  currentPlayerIndex: number;
  phase: 'setup' | 'playing' | 'trivia' | 'gameover';

  currentQuestion: TriviaQuestion | null;
  selectedAnswer: number | null;
  showResult: boolean;
  isCorrect: boolean | null;

  gameLog: string[];
  isTraining: boolean;
  highScore: number;

  // ─── Online mode bridge ───
  // When set, the action methods dispatch to the server instead of
  // mutating local state. The synced remote state is pushed back in via
  // syncFromRemote(). myTurn gates whether the local user may act.
  onlineDispatch: ((type: 'begin' | 'answer' | 'next' | 'skip', payload?: any) => void) | null;
  isOnline: boolean;
  myTurn: boolean;

  addPlayer: (name: string, color: PlayerColor) => void;
  removePlayer: (id: number) => void;
  startGame: () => void;
  setTrainingMode: (training: boolean) => void;
  beginQuestion: (difficulty: 'easy' | 'medium' | 'hard') => void;
  answerQuestion: (answerIndex: number) => void;
  nextTurn: () => void;
  resetGame: () => void;
  skipTrivia: () => void;

  setOnlineBridge: (dispatch: GameState['onlineDispatch'], myTurn: boolean) => void;
  syncFromRemote: (partial: Partial<GameState>) => void;
}

export const useGameStore = create<GameState>((set, get) => ({
  players: [],
  currentPlayerIndex: 0,
  phase: 'setup',
  currentQuestion: null,
  selectedAnswer: null,
  showResult: false,
  isCorrect: null,
  gameLog: [],
  isTraining: false,
  highScore: parseInt(localStorage.getItem('cdmx-patrol-highscore') || '0', 10),
  onlineDispatch: null,
  isOnline: false,
  myTurn: false,

  setOnlineBridge: (dispatch, myTurn) => set({ onlineDispatch: dispatch, isOnline: !!dispatch, myTurn }),
  syncFromRemote: (partial) => set(partial as any),

  setTrainingMode: (training) => set({ isTraining: training }),

  addPlayer: (name, color) => {
    set((state) => ({
      players: [...state.players, {
        id: state.players.length + 1,
        name,
        color,
        routeIndex: 0,
        currentDistrictId: patrolRoute[0],
        score: 0,
        answeredQuestions: [],
        badge: 'Cadet',
      }]
    }));
  },

  removePlayer: (id) => {
    set((state) => ({
      players: state.players.filter(p => p.id !== id)
    }));
  },

  startGame: () => {
    const state = get();
    if (state.players.length === 0) return;
    set({
      phase: 'playing',
      currentPlayerIndex: 0,
      gameLog: ['🚨 Mission briefing: Complete all 16 districts from Cuauhtémoc to Azcapotzalco!', `${state.players[0].name} begins the patrol at Cuauhtémoc.`],
    });
  },

  beginQuestion: (difficulty) => {
    const state = get();
    if (state.isOnline) {
      if (state.myTurn && state.onlineDispatch) state.onlineDispatch('begin', { difficulty });
      return;
    }
    const player = state.players[state.currentPlayerIndex];
    if (!player) return;
    const district = districts.find(d => d.id === player.currentDistrictId);
    if (!district) return;

    // Build the effective question list for this district:
    // Start with built-in questions, apply overrides, filter deleted
    const effectiveBuiltIn = district.trivia
      .filter(q => !deletedIdsRef.includes(q.id))
      .map(q => editedQuestionsRef[q.id] ? editedQuestionsRef[q.id].question : q);

    const allQuestions = [
      ...effectiveBuiltIn.filter(q => q.difficulty === difficulty),
      ...customQuestionsRef.filter(cq => cq.districtId === district.id && cq.question.difficulty === difficulty).map(cq => cq.question),
    ];

    if (allQuestions.length === 0) {
      // Fallback to any difficulty if no questions available
      const fallbackQuestions = [
        ...effectiveBuiltIn,
        ...customQuestionsRef.filter(cq => cq.districtId === district.id).map(cq => cq.question),
      ];
      if (fallbackQuestions.length === 0) return;
      const idx = Math.floor(Math.random() * fallbackQuestions.length);
      set({
        phase: 'trivia',
        currentQuestion: fallbackQuestions[idx],
        selectedAnswer: null,
        showResult: false,
        isCorrect: null,
      });
      return;
    }

    const idx = Math.floor(Math.random() * allQuestions.length);

    set({
      phase: 'trivia',
      currentQuestion: allQuestions[idx],
      selectedAnswer: null,
      showResult: false,
      isCorrect: null,
    });
  },

  answerQuestion: (answerIndex: number) => {
    const state = get();
    if (state.isOnline) {
      if (state.myTurn && state.onlineDispatch) state.onlineDispatch('answer', { answerIndex });
      return;
    }
    if (!state.currentQuestion || state.showResult) return;

    const correct = answerIndex === state.currentQuestion.correctAnswer;
    const player = state.players[state.currentPlayerIndex];
    const district = districts.find(d => d.id === player.currentDistrictId);

    const pointsMap = { easy: 10, medium: 20, hard: 30 };
    const points = correct ? pointsMap[state.currentQuestion.difficulty] : 0;

    const newScore = player.score + points;
    let newBadge = player.badge;
    if (newScore >= 400) newBadge = 'Comisario';
    else if (newScore >= 300) newBadge = 'Inspector';
    else if (newScore >= 200) newBadge = 'Oficial';
    else if (newScore >= 100) newBadge = 'Policia';
    else newBadge = 'Cadete';

    set((s) => ({
      selectedAnswer: answerIndex,
      showResult: true,
      isCorrect: correct,
      players: s.players.map((p, i) => {
        if (i !== s.currentPlayerIndex) return p;
        return {
          ...p,
          score: newScore,
          answeredQuestions: [...p.answeredQuestions, state.currentQuestion!.id],
          badge: newBadge,
        };
      }),
      gameLog: [...s.gameLog,
        correct
          ? `✅ ${player.name} answered correctly about ${district?.name}! +${points} pts`
          : `❌ ${player.name} answered incorrectly about ${district?.name}.`
      ]
    }));
  },

  skipTrivia: () => {
    const state = get();
    if (state.isOnline) {
      if (state.myTurn && state.onlineDispatch) state.onlineDispatch('skip');
      return;
    }
    set((s) => ({
      showResult: true,
      isCorrect: false,
      gameLog: [...s.gameLog, `${s.players[s.currentPlayerIndex].name} skipped the question.`]
    }));
  },

  nextTurn: () => {
    const state = get();
    if (state.isOnline) {
      if (state.myTurn && state.onlineDispatch) state.onlineDispatch('next');
      return;
    }
    const player = state.players[state.currentPlayerIndex];
    let updatedPlayers = [...state.players];

    // If correct (or training mode — always advance), move to next district
    if (state.isCorrect || state.isTraining) {
      const nextRouteIdx = player.routeIndex + 1;
      if (nextRouteIdx < patrolRoute.length) {
        updatedPlayers = updatedPlayers.map((p, i) => {
          if (i !== state.currentPlayerIndex) return p;
          return {
            ...p,
            routeIndex: nextRouteIdx,
            currentDistrictId: patrolRoute[nextRouteIdx],
          };
        });
      }
    }

    // Check if this player finished
    const updatedPlayer = updatedPlayers[state.currentPlayerIndex];
    const reachedEnd = updatedPlayer.routeIndex >= patrolRoute.length - 1;

    if (reachedEnd) {
      updatedPlayers = updatedPlayers.map((p, i) => {
        if (i !== state.currentPlayerIndex) return p;
        return { ...p, badge: 'Inspector' };
      });
    }

    // Check if all players completed
    const allDone = updatedPlayers.every(p => p.routeIndex >= patrolRoute.length - 1);

    if (allDone) {
      // Save high score for training mode
      const playerScore = updatedPlayers[state.currentPlayerIndex].score;
      const prevHigh = parseInt(localStorage.getItem('cdmx-patrol-highscore') || '0', 10);
      if (playerScore > prevHigh) {
        localStorage.setItem('cdmx-patrol-highscore', String(playerScore));
      }
      set({
        players: updatedPlayers,
        phase: 'gameover',
        highScore: Math.max(playerScore, prevHigh),
        gameLog: [...state.gameLog, '🏆 All cadets completed the patrol! Mission accomplished!']
      });
      return;
    }

    // Next player
    let nextIdx = (state.currentPlayerIndex + 1) % updatedPlayers.length;
    let safety = 0;
    while (updatedPlayers[nextIdx].routeIndex >= patrolRoute.length - 1 && safety < updatedPlayers.length) {
      nextIdx = (nextIdx + 1) % updatedPlayers.length;
      safety++;
    }

    const nextPlayer = updatedPlayers[nextIdx];

    const logMsg = reachedEnd
      ? `🎖️ ${player.name} completed the patrol route!`
      : '';

    set({
      players: updatedPlayers,
      currentPlayerIndex: nextIdx,
      phase: 'playing',
      currentQuestion: null,
      selectedAnswer: null,
      showResult: false,
      isCorrect: null,
      gameLog: logMsg
        ? [...state.gameLog, logMsg, `${nextPlayer.name}'s turn — at ${districts.find(d => d.id === nextPlayer.currentDistrictId)?.name}`]
        : [...state.gameLog, `${nextPlayer.name}'s turn — at ${districts.find(d => d.id === nextPlayer.currentDistrictId)?.name}`],
    });
  },

  resetGame: () => {
    set({
      players: [],
      currentPlayerIndex: 0,
      phase: 'setup',
      currentQuestion: null,
      selectedAnswer: null,
      showResult: false,
      isCorrect: null,
      gameLog: [],
      onlineDispatch: null,
      isOnline: false,
      isTraining: false,
      myTurn: false,
    });
  },
}));
