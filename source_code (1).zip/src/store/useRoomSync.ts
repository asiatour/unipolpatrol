import { useEffect, useRef, useCallback } from 'react';
import {
  useRoomStore,
  apiGetRoom,
  apiUpdateRoom,
  RoomGameState,
  RoomAction,
} from './roomStore';
import { drainQueue, startGameState, setEngineQuestionRefs } from './onlineEngine';
import { useCustomQuestions } from './useCustomQuestions';

const POLL_MS = 1500;

/**
 * Keeps the local room state in sync with the server.
 * - Guests: poll GET and render server state.
 * - Host: poll GET, drain the guest action queue, and PUT the new state.
 */
export function useRoomSync() {
  const { roomCode, isHost, gameState } = useRoomStore();
  const { customQuestions, editedQuestions, deletedIds } = useCustomQuestions();
  const busyRef = useRef(false);
  const gameStateRef = useRef<RoomGameState | null>(gameState);
  gameStateRef.current = gameState;

  // Feed question overrides into the engine so host resolves questions correctly
  useEffect(() => {
    setEngineQuestionRefs(customQuestions, editedQuestions, deletedIds);
  }, [customQuestions, editedQuestions, deletedIds]);

  useEffect(() => {
    if (!roomCode) return;
    let cancelled = false;

    const tick = async () => {
      if (busyRef.current) return;
      busyRef.current = true;
      try {
        const room = await apiGetRoom(roomCode);
        if (cancelled || !room) {
          busyRef.current = false;
          return;
        }

        if (isHost) {
          // Host is authoritative: drain queued guest actions and publish
          const { state, changed } = drainQueue(room.gameState);
          if (changed) {
            const updated = await apiUpdateRoom(roomCode, {
              gameState: state,
              status: state.phase === 'playing' || state.phase === 'trivia' || state.phase === 'roundResult' ? 'playing' : undefined,
            });
            if (!cancelled) {
              useRoomStore.getState().setRoom(roomCode, updated.status, updated.gameState);
            }
          } else {
            // still refresh players who joined the lobby
            useRoomStore.getState().setRoom(roomCode, room.status, room.gameState);
          }
        } else {
          // Guest: just mirror server state
          useRoomStore.getState().setRoom(roomCode, room.status, room.gameState);
        }
      } catch (e) {
        // network hiccup — keep last known state
      } finally {
        busyRef.current = false;
      }
    };

    tick();
    const interval = setInterval(tick, POLL_MS);
    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, [roomCode, isHost]);

  // Host: start the game (lobby -> playing)
  const hostStartGame = useCallback(async () => {
    const state = useRoomStore.getState();
    if (!state.roomCode || !state.isHost || !state.gameState) return;
    if (state.gameState.players.length === 0) return;
    const next = startGameState(state.gameState);
    const updated = await apiUpdateRoom(state.roomCode, { gameState: next, status: 'playing' });
    useRoomStore.getState().setRoom(state.roomCode, updated.status, updated.gameState);
  }, []);

  // Anyone: enqueue an action for the host to apply
  const sendAction = useCallback(
    async (type: RoomAction['type'], payload?: any) => {
      const state = useRoomStore.getState();
      if (!state.roomCode || !state.gameState) return;

      const action: RoomAction = {
        id: 'a-' + Math.random().toString(36).slice(2, 10) + Date.now().toString(36),
        playerId: state.myPlayerId,
        type,
        payload,
        ts: Date.now(),
      };

      if (state.isHost) {
        // Host applies immediately by pushing into its own queue then draining
        const withAction: RoomGameState = JSON.parse(JSON.stringify(state.gameState));
        withAction.actionQueue = [...(withAction.actionQueue || []), action];
        const { state: drained } = drainQueue(withAction);
        const updated = await apiUpdateRoom(state.roomCode, {
          gameState: drained,
          status: drained.phase === 'playing' || drained.phase === 'trivia' || drained.phase === 'roundResult' ? 'playing' : undefined,
        });
        useRoomStore.getState().setRoom(state.roomCode, updated.status, updated.gameState);
      } else {
        // Guest appends to server queue (read-modify-write)
        const room = await apiGetRoom(state.roomCode);
        if (!room) return;
        const gs: RoomGameState = room.gameState;
        gs.actionQueue = [...(gs.actionQueue || []), action];
        await apiUpdateRoom(state.roomCode, { gameState: gs });
      }
    },
    [],
  );

  return { hostStartGame, sendAction };
}
