import { useGameStore } from '../store/gameStore';
import { districts } from '../data/districts';
import { motion } from 'framer-motion';
import cdmxBadge from '../assets/cdmx-badge.png';

const colorMap: Record<string, string> = {
  car: '#2d6bc4',
  moto: '#c43d3d',
  horse: '#3d8b4f',
  foot: '#c8956c',
};

const iconMap: Record<string, string> = {
  car: '🚔',
  moto: '🏍️',
  horse: '🐴',
  foot: '🚶',
};

const medalEmoji = ['🥇', '🥈', '🥉', '🎖️'];

// CDMX outline for decorative background
const CDMX_OUTLINE = "M 480 42 C 510 36 545 40 575 52 C 605 64 628 84 645 112 C 662 140 670 174 674 212 C 678 250 678 290 674 328 C 670 362 660 394 645 422 C 630 450 610 472 586 490 C 562 508 534 520 504 528 C 474 536 442 540 410 540 C 378 540 346 536 316 528 C 286 520 258 508 234 490 C 210 472 192 450 180 422 C 168 394 162 362 160 328 C 158 290 162 252 172 218 C 182 184 198 154 220 130 C 242 106 270 90 302 80 C 334 70 368 68 402 72 C 420 56 448 46 480 42 Z";

export default function GameOver({ onOpenEditor, onNewGame }: { onOpenEditor?: () => void; onNewGame?: () => void }) {
  const { players, resetGame, phase, isTraining, highScore } = useGameStore();

  if (phase !== 'gameover') return null;

  const sorted = [...players].sort((a, b) => b.score - a.score);
  const winner = sorted[0];

  const handleNewGame = () => {
    if (onNewGame) {
      onNewGame();
    } else {
      resetGame();
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="min-h-screen bg-gradient-warm flex items-center justify-center p-6 relative overflow-hidden noise-overlay"
    >
      {/* Decorative CDMX outline in background */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <svg viewBox="0 0 800 600" className="w-full h-full opacity-[0.03]">
          <path d={CDMX_OUTLINE} fill="none" stroke="#c8956c" strokeWidth="2" />
        </svg>
      </div>

      <div className="text-center max-w-lg w-full relative z-10">
        <motion.div
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ type: 'spring', stiffness: 200, delay: 0.2 }}
          className="mb-6"
        >
          <div
            className="w-24 h-24 rounded-full overflow-hidden flex items-center justify-center mx-auto shadow-2xl"
            style={{ boxShadow: '0 20px 60px rgba(200, 149, 108, 0.4)' }}
          >
            <img src={cdmxBadge} alt="CDMX Seguridad Pública" className="w-full h-full object-cover" />
          </div>
        </motion.div>

        <h1 className="font-display text-5xl text-th-primary tracking-wider mb-2">MISSION COMPLETE!</h1>
        <p className="text-th-secondary text-sm mb-2">
          {isTraining ? 'Training session finished!' : 'All cadets have completed the 16-district patrol of Mexico City.'}
        </p>
        {isTraining && highScore > 0 && (
          <p className="text-sm font-bold" style={{ color: '#c8956c' }}>
            🏆 Personal High Score: {highScore} pts
          </p>
        )}

        {/* Winner */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="glass-card rounded-2xl p-6 mb-6"
        >
          <p className="text-[#c8956c] text-xs font-bold uppercase tracking-widest mb-3 font-display">TOP CADET</p>
          <div className="flex items-center justify-center gap-3 mb-3">
            <div
              className="w-14 h-14 rounded-full flex items-center justify-center text-white font-black text-xl shadow-lg"
              style={{ backgroundColor: colorMap[winner.color] }}
            >
              <span className="text-2xl">{iconMap[winner.color]}</span>
            </div>
            <div className="text-left">
              <p className="text-white font-black text-2xl">{winner.name}</p>
              <p className="text-th-secondary text-sm">Rank: {winner.badge}</p>
            </div>
          </div>
          <p className="font-display text-4xl" style={{ color: '#c8956c' }}>{winner.score} pts</p>
        </motion.div>

        {/* All players */}
        <div className="glass-card rounded-2xl p-4 mb-6">
          <h3 className="text-th-secondary text-xs font-bold uppercase tracking-wider mb-3 font-display">FINAL STANDINGS</h3>
          <div className="space-y-2">
            {sorted.map((player, idx) => (
              <motion.div
                key={player.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.6 + idx * 0.1 }}
                className="flex items-center gap-3 bg-white/[0.03] rounded-xl px-4 py-3"
              >
                <span className="text-xl w-8">{medalEmoji[idx] || '🎖️'}</span>
                <div
                  className="w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-xs flex-shrink-0"
                  style={{ backgroundColor: colorMap[player.color] }}
                >
                  <span className="text-sm">{iconMap[player.color]}</span>
                </div>
                <div className="flex-1 text-left">
                  <p className="text-white font-bold text-sm">{player.name}</p>
                  <p className="text-th-secondary text-[11px]">{player.badge} · {player.answeredQuestions.length} correct</p>
                </div>
                <p className="text-white font-black text-lg">{player.score}</p>
              </motion.div>
            ))}
          </div>
        </div>

        <div className="flex gap-3 justify-center">
          <motion.button
            whileHover={{ scale: 1.03, y: -1 }}
            whileTap={{ scale: 0.97 }}
            onClick={handleNewGame}
            className="px-8 py-3 btn-primary rounded-xl text-sm font-bold shadow-lg transition-all"
          >
            {isTraining ? 'Train Again 🎯' : 'New Mission 🔄'}
          </motion.button>
          {onOpenEditor && (
            <motion.button
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              onClick={onOpenEditor}
              className="px-5 py-3 bg-white/[0.04] border border-white/[0.06] text-th-secondary hover:text-th-primary font-bold rounded-xl transition-all text-sm"
            >
              📝 Questions
            </motion.button>
          )}
        </div>
      </div>
    </motion.div>
  );
}
