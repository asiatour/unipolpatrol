import { useState } from 'react';
import { useGameStore, PlayerColor } from '../store/gameStore';
import { motion } from 'framer-motion';
import cdmxBadge from '../assets/cdmx-badge.png';

const colorOptions: { color: PlayerColor; hex: string; icon: string; label: string }[] = [
  { color: 'car', hex: '#2d6bc4', icon: '🚔', label: 'Police Car' },
  { color: 'moto', hex: '#c43d3d', icon: '🏍️', label: 'Motorcycle' },
  { color: 'bike', hex: '#f5e642', icon: '🚲', label: 'Bicycle' },
  { color: 'horse', hex: '#3d8b4f', icon: '🐴', label: 'Mounted' },
  { color: 'foot', hex: '#c8956c', icon: '🚶', label: 'Foot Patrol' },
];

// CDMX outline for decorative background
const CDMX_OUTLINE = "M 480 42 C 510 36 545 40 575 52 C 605 64 628 84 645 112 C 662 140 670 174 674 212 C 678 250 678 290 674 328 C 670 362 660 394 645 422 C 630 450 610 472 586 490 C 562 508 534 520 504 528 C 474 536 442 540 410 540 C 378 540 346 536 316 528 C 286 520 258 508 234 490 C 210 472 192 450 180 422 C 168 394 162 362 160 328 C 158 290 162 252 172 218 C 182 184 198 154 220 130 C 242 106 270 90 302 80 C 334 70 368 68 402 72 C 420 56 448 46 480 42 Z";

export default function PlayerSetup({ onBack, onOpenEditor }: { onBack?: () => void; onOpenEditor?: () => void }) {
  const { players, addPlayer, removePlayer, startGame, phase } = useGameStore();
  const [name, setName] = useState('');
  const [selectedColor, setSelectedColor] = useState<PlayerColor>('car');

  if (phase !== 'setup') return null;

  const usedColors = players.map(p => p.color);

  const handleAdd = () => {
    if (name.trim() && !usedColors.includes(selectedColor)) {
      addPlayer(name.trim(), selectedColor);
      // Auto-start the game after adding the player
      startGame();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-warm flex items-center justify-center p-4 relative overflow-hidden noise-overlay">
      {/* Decorative CDMX outline in background */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <svg viewBox="0 0 800 600" className="w-full h-full opacity-[0.04]">
          <path d={CDMX_OUTLINE} fill="none" stroke="#c8956c" strokeWidth="2" />
        </svg>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
        className="w-full max-w-lg relative z-10"
      >
        {/* Title */}
        <div className="text-center mb-8">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.1, type: 'spring', stiffness: 200 }}
            className="w-20 h-20 rounded-2xl overflow-hidden shadow-2xl mx-auto mb-5"
            style={{ boxShadow: '0 20px 60px rgba(200, 149, 108, 0.3)' }}
          >
            <img src={cdmxBadge} alt="CDMX Seguridad Pública" className="w-full h-full object-cover" />
          </motion.div>
          <h1 className="font-display text-5xl text-th-primary tracking-wider leading-none mb-2">
            CDMX <span style={{ color: '#c8956c' }}>PATROL</span>
          </h1>
          <p className="text-th-secondary text-sm mt-3 max-w-sm mx-auto leading-relaxed whitespace-nowrap">
            Complete the patrol route through all 16 CDMX boroughs
          </p>
        </div>

        {/* Setup Card */}
        <div className="glass-card rounded-2xl p-6">
          <h2 className="text-th-primary font-display text-lg tracking-wider mb-5">TRAINING RANGE</h2>

          <div>
            <label className="text-th-secondary text-[11px] uppercase tracking-widest font-bold mb-1.5 block">Cadet Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleAdd()}
              placeholder="Enter your name..."
              maxLength={12}
              className="w-full bg-white/[0.04] border border-th-medium rounded-xl px-4 py-3 text-th-primary placeholder-th-muted text-sm focus:outline-none focus:ring-1 focus:ring-[#c8956c]/50 focus:border-[#c8956c]/50 transition-all"
            />
          </div>

          {/* Transport selection */}
          <div className="mt-4">
            <label className="text-th-secondary text-[11px] uppercase tracking-widest font-bold mb-2 block">Choose Your Transport</label>
            <div className="flex gap-2">
              {colorOptions.map(opt => {
                const isSelected = selectedColor === opt.color;
                return (
                  <button
                    key={opt.color}
                    onClick={() => setSelectedColor(opt.color)}
                    className={`flex-1 py-2.5 rounded-lg text-xs font-bold transition-all border-2 flex flex-col items-center gap-0.5 ${
                      isSelected
                        ? 'border-white/80 scale-105'
                        : 'border-transparent hover:border-white/30'
                    }`}
                    style={{ backgroundColor: opt.hex }}
                  >
                    <span className="text-lg leading-none">{opt.icon}</span>
                    <span className="text-th-primary text-[10px] drop-shadow-sm">{opt.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Mission briefing */}
          <div className="bg-white/[0.02] rounded-xl border border-white/[0.04] p-4 mt-5 mb-5">
            <h3 className="text-th-secondary text-[11px] font-bold uppercase tracking-wider mb-3 font-display">MISSION BRIEFING</h3>
            <div className="space-y-2 text-[11px] text-th-secondary">
              <p className="whitespace-nowrap">🏛️ <span className="text-th-primary font-medium">Route:</span> Cuauhtémoc (1) → Gustavo A. Madero (16)</p>
              <p>🎚️ <span className="text-th-primary font-medium">Difficulty:</span> Choose Easy 10 · Medium 20 · Hard 30 pts for each borough</p>
              <p>➡️ <span className="text-th-primary font-medium">Advance:</span> You always move to the next borough, right or wrong</p>
              <p>🏆 <span className="text-th-primary font-medium">Goal:</span> Complete the patrol and set your personal high score</p>
            </div>
          </div>

          {/* Start button */}
          <div className="flex gap-2 pt-1">
            {onBack && (
              <button
                onClick={onBack}
                className="px-4 py-3 rounded-xl text-sm text-th-secondary hover:text-th-primary hover:bg-white/[0.04] transition-all"
              >
                ← Back
              </button>
            )}
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleAdd}
              disabled={!name.trim()}
              className="flex-1 py-3 btn-primary disabled:bg-white/[0.06] disabled:text-white/20 disabled:cursor-not-allowed rounded-xl text-sm font-bold transition-all"
            >
              Begin Training 🎯
            </motion.button>
            {onOpenEditor && (
              <button
                onClick={onOpenEditor}
                className="px-4 py-3 bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.06] text-th-secondary hover:text-th-primary rounded-xl text-sm font-medium transition-all"
                title="Open Question Editor"
              >
                📝
              </button>
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
}
