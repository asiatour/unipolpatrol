import { useGameStore } from '../store/gameStore';
import { districts } from '../data/districts';
import { motion, AnimatePresence } from 'framer-motion';

const categoryEmoji: Record<string, string> = {
  geography: '🌍',
  landmarks: '🏛️',
  crimes: '🚔',
  english: '🔤',
  misc: '📋',
};

const difficultyColors: Record<string, { bg: string; text: string; border: string }> = {
  easy: { bg: 'rgba(61,139,79,0.1)', text: '#5aab6f', border: 'rgba(61,139,79,0.2)' },
  medium: { bg: 'rgba(201,168,37,0.1)', text: '#e0c040', border: 'rgba(201,168,37,0.2)' },
  hard: { bg: 'rgba(196,61,61,0.1)', text: '#e05555', border: 'rgba(196,61,61,0.2)' },
};

const zoneColors: Record<string, string> = {
  start: '#e8e4df',
  tourist: '#2d6bc4',
  city: '#3d8b4f',
  emergency: '#c9a825',
  victory: '#c43d3d',
};

export default function TriviaCard() {
  const { currentQuestion, answerQuestion, showResult, selectedAnswer, isCorrect, nextTurn, skipTrivia, phase, currentPlayerIndex, players } = useGameStore();

  if (phase !== 'trivia' || !currentQuestion) return null;

  const player = players[currentPlayerIndex];
  const district = districts.find(d => d.id === player?.currentDistrictId);
  const zoneColor = district ? zoneColors[district.level] : '#c8956c';
  const diff = difficultyColors[currentQuestion.difficulty];

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.96 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: -20, scale: 0.96 }}
        transition={{ type: 'spring', stiffness: 300, damping: 25 }}
        className="w-full max-w-md mx-auto"
      >
        <div className="glass-card rounded-2xl overflow-hidden">
          {/* Header */}
          <div
            className="px-4 py-3 flex items-center justify-between"
            style={{ backgroundColor: `${zoneColor}20`, borderBottom: `1px solid ${zoneColor}20` }}
          >
            <div className="flex items-center gap-2">
              <span className="text-sm">{district?.icon} {categoryEmoji[currentQuestion.category]} <span className="text-th-secondary text-[10px] font-bold capitalize">{currentQuestion.category}</span></span>
              <span className="text-th-primary font-bold text-xs">#{district?.id} {district?.name}</span>
            </div>
            <div className="flex items-center gap-2">
              <span
                className="px-2 py-0.5 rounded text-[10px] font-bold border"
                style={{ backgroundColor: diff.bg, color: diff.text, borderColor: diff.border }}
              >
                {currentQuestion.difficulty.toUpperCase()}
              </span>
              <span className="text-[10px] font-bold" style={{ color: '#c8956c' }}>
                +{currentQuestion.difficulty === 'easy' ? 10 : currentQuestion.difficulty === 'medium' ? 20 : 30} pts
              </span>
            </div>
          </div>

          {/* Question */}
          <div className="px-4 py-4">
            <h3 className="text-sm font-bold text-th-primary leading-snug">
              {currentQuestion.question}
            </h3>
          </div>

          {/* Options */}
          <div className="px-4 pb-4 grid grid-cols-2 gap-2">
            {currentQuestion.options.map((option, idx) => {
              const isSelected = selectedAnswer === idx;
              const isCorrectAnswer = idx === currentQuestion.correctAnswer;

              let optionStyle = 'bg-white/[0.03] border-white/[0.06] hover:border-[#c8956c]/30 hover:bg-white/[0.06]';
              if (showResult) {
                if (isCorrectAnswer) {
                  optionStyle = 'bg-[#3d8b4f]/10 border-[#3d8b4f]/40 ring-1 ring-[#3d8b4f]/20';
                } else if (isSelected && !isCorrectAnswer) {
                  optionStyle = 'bg-[#c43d3d]/10 border-[#c43d3d]/40 ring-1 ring-[#c43d3d]/20';
                } else {
                  optionStyle = 'bg-white/[0.01] border-white/[0.04] opacity-40';
                }
              }

              return (
                <motion.button
                  key={idx}
                  whileHover={!showResult ? { scale: 1.01 } : undefined}
                  whileTap={!showResult ? { scale: 0.99 } : undefined}
                  onClick={() => !showResult && answerQuestion(idx)}
                  disabled={showResult}
                  className={`text-left px-4 py-3 rounded-xl border text-sm font-medium transition-all ${optionStyle}`}
                >
                  <span className="text-th-secondary">
                    <span className="text-th-muted mr-2">{String.fromCharCode(65 + idx)}.</span>
                    {option}
                  </span>
                  {showResult && isCorrectAnswer && (
                    <span className="ml-2 text-[#3d8b4f]">✓</span>
                  )}
                  {showResult && isSelected && !isCorrectAnswer && (
                    <span className="ml-2 text-[#c43d3d]">✗</span>
                  )}
                </motion.button>
              );
            })}
          </div>

          {/* Result feedback */}
          {showResult && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="px-4 pb-4"
            >
              <div className={`rounded-xl p-3 text-center ${isCorrect ? 'bg-[#3d8b4f]/10 border border-[#3d8b4f]/20' : 'bg-[#c43d3d]/10 border border-[#c43d3d]/20'}`}>
                <p className={`font-bold text-sm ${isCorrect ? 'text-[#5aab6f]' : 'text-[#e05555]'}`}>
                  {isCorrect ? '✅ Correct! +10 pts' : '❌ Incorrect'}
                </p>
                {!isCorrect && (
                  <p className="text-th-secondary text-[11px] mt-1">
                    The correct answer was: {currentQuestion.options[currentQuestion.correctAnswer]}
                  </p>
                )}
              </div>
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={nextTurn}
                className="w-full mt-3 py-2.5 btn-primary rounded-xl text-sm font-bold"
              >
                Continue →
              </motion.button>
            </motion.div>
          )}
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
