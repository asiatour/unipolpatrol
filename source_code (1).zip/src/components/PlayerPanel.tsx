import { useGameStore } from '../store/gameStore';
import { districts, patrolRoute } from '../data/districts';
import { motion } from 'framer-motion';

const colorMap: Record<string, string> = {
  car: '#2d6bc4',
  moto: '#c43d3d',
  horse: '#3d8b4f',
  foot: '#c8956c',
};

const iconMap: Record<string, string> = {
  car: '🚔',
  moto: '🏍️',
  horse: '🐴',
  foot: '🚶',
};

const badgeColors: Record<string, string> = {
  Cadet: 'bg-white/[0.06] text-th-muted',
  Corporal: 'bg-[#2d6bc4]/20 text-[#4a8ae0]',
  Lieutenant: 'bg-[#3d8b4f]/20 text-[#5aab6f]',
  Sergeant: 'bg-[#c8956c]/20 text-[#c8956c]',
  Inspector: 'bg-[#c9a825]/20 text-[#e0c040]',
};

export default function PlayerPanel() {
  const { players, currentPlayerIndex, phase, gameLog } = useGameStore();
  const currentPlayer = players[currentPlayerIndex];

  if (phase === 'setup') return null;

  return (
    <div className="flex flex-col gap-3 w-full">
      {/* Players */}
      <div className="glass-card rounded-2xl p-4">
        <h3 className="text-th-secondary text-[11px] font-bold uppercase tracking-wider mb-3 font-display">CADETS</h3>
        <div className="space-y-2.5">
          {players.map((player, idx) => {
            const isActive = idx === currentPlayerIndex && phase !== 'gameover';
            const district = districts.find(d => d.id === player.currentDistrictId);
            const progress = player.routeIndex + 1;
            const progressPercent = (progress / patrolRoute.length) * 100;
            const completed = player.routeIndex >= patrolRoute.length - 1;

            return (
              <motion.div
                key={player.id}
                animate={isActive ? { scale: 1.02 } : { scale: 1 }}
                className={`rounded-xl p-3 transition-all ${
                  isActive
                    ? 'bg-white/[0.06] border border-[#c8956c]/20 shadow-lg'
                    : completed
                      ? 'bg-[#3d8b4f]/[0.06] border border-[#3d8b4f]/20'
                      : 'bg-white/[0.02] border border-white/[0.04]'
                }`}
              >
                <div className="flex items-center gap-2.5 mb-2">
                  <div
                    className="w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-xs shadow-md flex-shrink-0"
                    style={{ backgroundColor: colorMap[player.color] }}
                  >
                    <span className="text-sm">{iconMap[player.color]}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-white font-bold text-sm truncate">{player.name}</p>
                      {isActive && <span className="text-[10px] animate-pulse" style={{ color: '#c8956c' }}>▶</span>}
                      {completed && <span className="text-[10px]">🎖️</span>}
                    </div>
                    <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-bold ${badgeColors[player.badge]}`}>
                      {player.badge}
                    </span>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p className="text-white font-black text-lg leading-none">{player.score}</p>
                    <p className="text-th-muted text-[10px]">pts</p>
                  </div>
                </div>
                {/* Progress */}
                <div>
                  <div className="flex items-center justify-between mb-0.5">
                    <p className="text-th-secondary text-[10px]">
                      📍 #{player.routeIndex + 1} {district?.name}
                    </p>
                    <p className="text-th-muted text-[10px]">
                      {progress}/16
                    </p>
                  </div>
                  <div className="h-1 bg-white/[0.04] rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{ width: `${progressPercent}%`, backgroundColor: colorMap[player.color] }}
                    />
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Game Log */}
      {gameLog.length > 0 && (
        <div className="glass-card rounded-2xl p-4">
          <h3 className="text-th-secondary text-[11px] font-bold uppercase tracking-wider mb-3 font-display">LOG</h3>
          <div className="space-y-1.5 max-h-32 overflow-y-auto">
            {gameLog.slice(-6).reverse().map((log, idx) => (
              <p key={idx} className="text-th-muted text-[10px] leading-relaxed">
                {log}
              </p>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
