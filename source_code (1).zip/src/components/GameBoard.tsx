import { districts, levels, patrolRoute, specialTransitions } from '../data/districts';
import { useGameStore, Player } from '../store/gameStore';
import { motion } from 'framer-motion';
import cdmxMap from '../assets/cdmx-map.png';

const colorMap: Record<string, string> = {
  car: '#2d6bc4',
  moto: '#c43d3d',
  horse: '#3d8b4f',
  foot: '#c8956c',
};

const iconMap: Record<string, string> = {
  car: '🚔',
  moto: '🏍️',
  horse: '🐴',
  foot: '🚶',
};

// Number positions mapped from reference image (870x1160 portrait)
// Image rendered at: x=182..618, y=10..590 (436w x 580h, xMidYMid meet)
// Each position is the district name center + 15px offset below
const DISTRICT_POSITIONS: Record<number, [number, number]> = {
  1: [403, 230],   // Cuauhtémoc
  2: [373, 185],   // Azcapotzalco
  3: [338, 235],   // Miguel Hidalgo
  4: [243, 315],   // Cuajimalpa
  5: [313, 315],   // Álvaro Obregón
  6: [278, 395],   // Magdalena Contreras
  7: [393, 275],   // Benito Juárez
  8: [398, 330],   // Coyoacán
  9: [358, 450],   // Tlalpan
  10: [458, 390],  // Xochimilco
  11: [493, 485],  // Milpa Alta
  12: [533, 345],  // Tláhuac
  13: [498, 285],  // Iztapalapa
  14: [443, 245],  // Iztacalco
  15: [443, 220],  // Venustiano Carranza
  16: [443, 150],  // Gustavo A. Madero
};

export default function GameBoard() {
  const { players, currentPlayerIndex, phase } = useGameStore();
  const currentPlayer = players[currentPlayerIndex];
  if (phase === 'setup' || phase === 'gameover') return null;

  return (
    <div className="w-full h-full flex flex-col overflow-hidden">
      <div className="flex-1 relative min-h-0">
        <svg viewBox="0 0 800 600" className="w-full h-full" style={{ height: '100%' }}>
          <defs>
            <radialGradient id="mapBg" cx="50%" cy="50%" r="55%">
              <stop offset="0%" stopColor="#2a2622" />
              <stop offset="100%" stopColor="#1a1816" />
            </radialGradient>
            <filter id="textShadow">
              <feDropShadow dx="0" dy="1" stdDeviation="1.5" floodColor="#000000" floodOpacity="0.8" />
            </filter>
            <filter id="currentGlow">
              <feGaussianBlur stdDeviation="4" result="blur" />
              <feFlood floodColor="#c8956c" floodOpacity="0.5" result="color" />
              <feComposite in="color" in2="blur" operator="in" result="glow" />
              <feMerge><feMergeNode in="glow" /><feMergeNode in="SourceGraphic" /></feMerge>
            </filter>
            <marker id="arrowDefault" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse">
              <path d="M 0 0 L 10 5 L 0 10 z" fill="#c8956c" opacity="0.6" />
            </marker>
          </defs>

          {/* Background */}
          <rect width="800" height="600" fill="url(#mapBg)" />

          {/* Reference map image */}
          <image
            href={cdmxMap}
            x="80"
            y="10"
            width="640"
            height="580"
            preserveAspectRatio="xMidYMid meet"
            opacity="0.92"
          />

          {/* Route arrows */}
          {patrolRoute.map((dId, idx) => {
            if (idx === patrolRoute.length - 1) return null;
            const from = DISTRICT_POSITIONS[dId];
            const to = DISTRICT_POSITIONS[patrolRoute[idx + 1]];
            if (!from || !to) return null;
            const [x1, y1] = from;
            const [x2, y2] = to;
            const mx = (x1 + x2) / 2;
            const my = (y1 + y2) / 2;
            const dx = x2 - x1;
            const dy = y2 - y1;
            return (
              <g key={"arrow-" + dId} opacity="0.35">
                <path
                  d={"M " + x1 + " " + y1 + " Q " + (mx + dy * 0.1) + " " + (my - dx * 0.1) + " " + x2 + " " + y2}
                  fill="none"
                  stroke="#c8956c"
                  strokeWidth="1.2"
                  strokeDasharray="4,3"
                  markerEnd="url(#arrowDefault)"
                />
              </g>
            );
          })}

          {/* Game markers - plain numbers, no circles */}
          {districts.map(district => {
            const pos = DISTRICT_POSITIONS[district.id];
            if (!pos) return null;
            const [cx, cy] = pos;
            const playersHere = players.filter(p => p.currentDistrictId === district.id);
            const isCurrentPlayerHere = playersHere.some(p => p.id === currentPlayer?.id);
            const routeIdx = patrolRoute.indexOf(district.id);
            const isCompleted = players.some(p => p.routeIndex > routeIdx);

            return (
              <g key={district.id}>
                {/* Current player indicator - subtle glow behind number */}
                {isCurrentPlayerHere && (
                  <circle cx={cx} cy={cy} r="12" fill="#c8956c" opacity="0.25">
                    <animate attributeName="r" values="10;16;10" dur="2s" repeatCount="indefinite" />
                    <animate attributeName="opacity" values="0.25;0.1;0.25" dur="2s" repeatCount="indefinite" />
                  </circle>
                )}

                {/* Plain number */}
                <text
                  x={cx}
                  y={cy + 4}
                  textAnchor="middle"
                  fill={district.id === 1 ? '#1a1816' : isCompleted ? 'rgba(200,149,108,0.4)' : '#FFFFFF'}
                  fontSize="13"
                  fontWeight="900"
                  fontFamily="'Bebas Neue', system-ui"
                  filter={isCurrentPlayerHere ? 'url(#currentGlow)' : 'url(#textShadow)'}
                  style={{ pointerEvents: 'none' }}
                >
                  {district.id}
                </text>

                {/* Player tokens */}
                {playersHere.length > 0 && (
                  <g transform={"translate(" + cx + ", " + (cy - 35) + ")"}>
                    {playersHere.map((player, idx) => {
                      const ox = idx * 14 - (playersHere.length - 1) * 7;
                      return (
                        <g key={player.id} transform={"translate(" + ox + ", 0)"}>
                          <circle r="7" fill={colorMap[player.color]} stroke="rgba(0,0,0,0.4)" strokeWidth="1" />
                          <text y="3" textAnchor="middle" fontSize="8" style={{ pointerEvents: 'none' }}>{iconMap[player.color]}</text>
                        </g>
                      );
                    })}
                  </g>
                )}
              </g>
            );
          })}

          {/* Title */}
          <text x="400" y="26" textAnchor="middle" fill="rgba(245,240,235,0.35)" fontSize="12" fontWeight="400" fontFamily="'Bebas Neue', system-ui" letterSpacing="4">CDMX PATROL ENGLISH</text>

          {/* Compass */}
          <g transform="translate(735, 42)">
            <circle r="18" fill="rgba(0,0,0,0.3)" stroke="rgba(200,149,108,0.25)" strokeWidth="1" />
            <text y="-2" textAnchor="middle" fill="rgba(200,149,108,0.6)" fontSize="11" fontWeight="bold" fontFamily="'Bebas Neue', system-ui">N</text>
            <line x1="0" y1="-12" x2="0" y2="-7" stroke="rgba(200,149,108,0.5)" strokeWidth="1.5" />
          </g>
        </svg>
      </div>
      <PatrolRouteTracker />
    </div>
  );
}

function PatrolRouteTracker() {
  const { players, currentPlayerIndex } = useGameStore();
  const currentPlayer = players[currentPlayerIndex];
  if (!currentPlayer) return null;
  return (
    <div className="glass-card rounded-xl px-3 py-2 mt-1">
      <div className="flex items-center gap-1 overflow-x-auto">
        <span className="text-th-secondary text-[10px] font-bold uppercase tracking-wider mr-1 flex-shrink-0 font-display">Route:</span>
        {patrolRoute.map((dId, idx) => {
          const district = districts.find(d => d.id === dId);
          const isCurrent = currentPlayer.currentDistrictId === dId;
          const isPast = currentPlayer.routeIndex > idx;
          const zoneColor = district?.level === 'start' ? '#e8e4df' : district?.level === 'tourist' ? '#2d6bc4' : district?.level === 'city' ? '#3d8b4f' : district?.level === 'emergency' ? '#c9a825' : '#c43d3d';
          return (
            <div key={dId} className="flex items-center flex-shrink-0">
              <div className={"w-6 h-6 rounded-full flex items-center justify-center text-[9px] font-bold transition-all " + (isCurrent ? 'text-white ring-2 ring-[#c8956c] scale-110' : isPast ? 'text-th-primary' : 'text-th-muted')} style={{ backgroundColor: isCurrent ? zoneColor : isPast ? zoneColor + '80' : zoneColor + '20' }}>{dId}</div>
              {idx < patrolRoute.length - 1 && <span className="text-th-muted text-[7px] mx-0.5">\u2192</span>}
            </div>
          );
        })}
      </div>
    </div>
  );
}
