import { useGameStore } from '../store/gameStore';
import { districts } from '../data/districts';
import { motion } from 'framer-motion';

const difficultyConfig = [
  { level: 'easy' as const, label: 'Easy', points: 10, color: '#3d8b4f', emoji: '🟢' },
  { level: 'medium' as const, label: 'Medium', points: 20, color: '#c9a825', emoji: '🟡' },
  { level: 'hard' as const, label: 'Hard', points: 30, color: '#c43d3d', emoji: '🔴' },
];

export default function ActionBar() {
  const { currentPlayerIndex, players, phase, beginQuestion } = useGameStore();
  const player = players[currentPlayerIndex];

  if (phase === 'setup' || phase === 'gameover' || !player) return null;

  const district = districts.find(d => d.id === player.currentDistrictId);
  const isCompleted = player.routeIndex >= 15;

  if (isCompleted) {
    return (
      <div className="glass-card rounded-2xl p-5 text-center">
        <span className="text-2xl">🎖️</span>
        <p className="font-bold text-sm mt-2" style={{ color: '#3d8b4f' }}>{player.name} completed the patrol!</p>
      </div>
    );
  }

  if (phase === 'playing') {
    return (
      <div className="glass-card rounded-2xl p-5 text-center">
        <p className="text-th-muted text-[11px] uppercase tracking-widest font-bold mb-2 font-display">
          {player.name}'s Turn
        </p>
        <div className="flex items-center justify-center gap-2 mb-4">
          <div
            className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold shadow-md"
            style={{ backgroundColor: district?.color === '#FFFFFF' ? '#e8e4df' : district?.color }}
          >
            {district?.icon}
          </div>
          <div className="text-left">
            <p className="text-white font-bold text-sm leading-tight">
              #{player.routeIndex + 1} {district?.name}
            </p>
            {district?.subtitle && (
              <p className="text-th-muted text-[10px]">{district.subtitle}</p>
            )}
          </div>
        </div>
        <p className="text-th-secondary text-[11px] mb-4">
          Choose difficulty for this borough:
        </p>
        <div className="flex gap-2">
          {difficultyConfig.map((diff) => (
            <motion.button
              key={diff.level}
              whileHover={{ scale: 1.03, y: -1 }}
              whileTap={{ scale: 0.97 }}
              onClick={() => beginQuestion(diff.level)}
              className="flex-1 py-3 rounded-xl text-sm font-bold transition-all flex flex-col items-center gap-1"
              style={{ backgroundColor: `${diff.color}20`, border: `1px solid ${diff.color}40`, color: diff.color }}
            >
              <span className="text-lg leading-none">{diff.emoji}</span>
              <span>{diff.label}</span>
              <span className="text-[10px] opacity-70">+{diff.points} pts</span>
            </motion.button>
          ))}
        </div>
      </div>
    );
  }

  return null;
}
