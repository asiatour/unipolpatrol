import { questions, rooms, questionOverrides, questionDeletions, deletedCustomQuestions } from "./db_schema";

export const drizzleSchema = { questions, rooms, questionOverrides, questionDeletions, deletedCustomQuestions };

export const buckets = {} as const;

export const VarKey = {} as const;

export const SecretKey = {} as const;
