import { Hono } from "hono";
import { questions as questionsTable, rooms as roomsTable } from "./__generated__/sys_schema.js";
import { eq } from "drizzle-orm";

const app = new Hono();

// CORS for frontend
app.use("*", async (c, next) => {
  c.header("Access-Control-Allow-Origin", "*");
  c.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
  c.header("Access-Control-Allow-Headers", "Content-Type, Authorization");
  if (c.req.method === "OPTIONS") {
    return c.text("", 204);
  }
  await next();
});

// ─── Questions (Public - no auth required) ───

// Get all questions (or filter by district)
app.get("/api/public/questions", async (c) => {
  const es = (app as any)._edgespark;
  if (!es) return c.json({ data: [] });
  const districtId = c.req.query("district_id");
  let results;
  if (districtId) {
    results = await es.db
      .select()
      .from(questionsTable)
      .where(eq(questionsTable.districtId, parseInt(districtId)));
  } else {
    results = await es.db.select().from(questionsTable);
  }
  return c.json({ data: results });
});

// Create a question
app.post("/api/public/questions", async (c) => {
  const es = (app as any)._edgespark;
  if (!es) return c.json({ error: "Backend not initialized" }, 500);
  const body = await c.req.json();
  const {
    district_id, question_id, question_text,
    option_0, option_1, option_2, option_3,
    correct_answer, difficulty, category,
  } = body;

  if (!question_text || !question_id) {
    return c.json({ error: "Missing required fields" }, 400);
  }

  const result = await es.db
    .insert(questionsTable)
    .values({
      districtId: district_id,
      questionId: question_id,
      questionText: question_text,
      option0: option_0,
      option1: option_1,
      option2: option_2,
      option3: option_3,
      correctAnswer: correct_answer,
      difficulty,
      category,
      createdBy: es.auth.user?.id || null,
      createdAt: Math.floor(Date.now() / 1000),
    })
    .returning();

  return c.json({ data: result[0] }, 201);
});

// Update a question
app.put("/api/public/questions/:questionId", async (c) => {
  const es = (app as any)._edgespark;
  if (!es) return c.json({ error: "Backend not initialized" }, 500);
  const questionId = c.req.param("questionId");
  const body = await c.req.json();

  const result = await es.db
    .update(questionsTable)
    .set({
      questionText: body.question_text,
      option0: body.option_0,
      option1: body.option_1,
      option2: body.option_2,
      option3: body.option_3,
      correctAnswer: body.correct_answer,
      difficulty: body.difficulty,
      category: body.category,
    })
    .where(eq(questionsTable.questionId, questionId))
    .returning();

  if (result.length === 0) return c.json({ error: "Not found" }, 404);
  return c.json({ data: result[0] });
});

// Delete a question
app.delete("/api/public/questions/:questionId", async (c) => {
  const es = (app as any)._edgespark;
  if (!es) return c.json({ error: "Backend not initialized" }, 500);
  const questionId = c.req.param("questionId");
  const result = await es.db
    .delete(questionsTable)
    .where(eq(questionsTable.questionId, questionId))
    .returning();

  if (result.length === 0) return c.json({ error: "Not found" }, 404);
  return c.json({ success: true });
});

// ─── Game Rooms (Protected - auth required) ───

app.get("/api/rooms/:code", async (c) => {
  const es = (app as any)._edgespark;
  if (!es) return c.json({ error: "Backend not initialized" }, 500);
  const code = c.req.param("code");
  const result = await es.db
    .select()
    .from(roomsTable)
    .where(eq(roomsTable.code, code));

  if (result.length === 0) return c.json({ error: "Room not found" }, 404);
  return c.json({ data: result[0] });
});

app.post("/api/rooms", async (c) => {
  const es = (app as any)._edgespark;
  if (!es) return c.json({ error: "Backend not initialized" }, 500);
  const body = await c.req.json();
  const code = body.code || Math.random().toString(36).substring(2, 8).toUpperCase();

  const result = await es.db
    .insert(roomsTable)
    .values({
      code,
      hostPlayerId: es.auth.user?.id || null,
      gameState: JSON.stringify({ players: [], phase: "lobby", currentTurn: 0 }),
      status: "waiting",
      createdAt: Math.floor(Date.now() / 1000),
    })
    .returning();

  return c.json({ data: result[0] }, 201);
});

app.put("/api/rooms/:code", async (c) => {
  const es = (app as any)._edgespark;
  if (!es) return c.json({ error: "Backend not initialized" }, 500);
  const code = c.req.param("code");
  const body = await c.req.json();

  const result = await es.db
    .update(roomsTable)
    .set({ gameState: JSON.stringify(body.gameState), status: body.status })
    .where(eq(roomsTable.code, code))
    .returning();

  if (result.length === 0) return c.json({ error: "Room not found" }, 404);
  return c.json({ data: result[0] });
});

export default app;
