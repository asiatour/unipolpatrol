/**
 * EDGESPARK SERVER
 *
 * Create and return your Hono app.
 * See @sdk/server-types for SDK API.
 *
 * ═══════════════════════════════════════════════════════════════════
 * ✅ WHAT YOU CAN DO
 * ═══════════════════════════════════════════════════════════════════
 *
 * - Create a Hono app and define routes
 * - Use edgespark.db for database operations (Drizzle ORM)
 * - Use edgespark.storage for file operations
 * - Use edgespark.auth.user for authenticated user info
 * - Access request data: c.req.json(), c.req.param(), c.req.query()
 * - Return responses: c.json(), c.text(), c.html()
 *
 * ═══════════════════════════════════════════════════════════════════
 * ❌ WHAT YOU CANNOT DO
 * ═══════════════════════════════════════════════════════════════════
 *
 * - DON'T forget to return the app
 * - DON'T remove required imports
 *
 * ═══════════════════════════════════════════════════════════════════
 * 📚 API DOCUMENTATION
 * ═══════════════════════════════════════════════════════════════════
 *
 * See @sdk/server-types for complete API documentation with examples.
 */

import { Hono } from "hono";
import type { Client } from "@sdk/server-types";
import { tables, buckets } from "@generated";
import { eq } from "drizzle-orm";

/**
 * Create your Hono app
 * @param edgespark - EdgeSpark SDK client
 * @returns Hono app with your routes defined
 */
export async function createApp(
  edgespark: Client<typeof tables>
): Promise<Hono> {
  const app = new Hono();

  // ═══════════════════════════════════════════════════════════
  // CORS
  // ═══════════════════════════════════════════════════════════
  app.use("*", async (c, next) => {
    c.header("Access-Control-Allow-Origin", "*");
    c.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    c.header("Access-Control-Allow-Headers", "Content-Type, Authorization");
    if (c.req.method === "OPTIONS") {
      return c.text("", 204 as any);
    }
    await next();
  });

  // ═══════════════════════════════════════════════════════════
  // PATH CONVENTIONS (Authentication)
  //
  // /api/*          → Login required (edgespark.auth.user guaranteed)
  // /api/public/*   → Login optional (edgespark.auth.user if logged in)
  // /api/webhooks/* → No auth check (handle verification yourself)
  // ═══════════════════════════════════════════════════════════

  // ═══════════════════════════════════════════════════════════
  // NO AUTH REQUIRED
  //
  // Every route (reads AND writes) lives under /api/public/* so
  // nothing requires a login. The teacher sign-in gate was removed
  // so the content editor is never locked.
  // ═══════════════════════════════════════════════════════════

  // Test endpoint
  app.get("/api/public/hello", (c) => c.json({ message: "Hello from EdgeSpark! Spark your idea to the Edge." }));

  // ─── Questions CRUD (all public — no login required) ────

  // Get all questions (or filter by district_id)
  app.get("/api/public/questions", async (c) => {
    const districtId = c.req.query("district_id");
    let results;
    if (districtId) {
      results = await edgespark.db
        .select()
        .from(tables.questions)
        .where(eq(tables.questions.districtId, parseInt(districtId)));
    } else {
      results = await edgespark.db.select().from(tables.questions);
    }
    return c.json({ data: results });
  });

  // Create a question (public)
  app.post("/api/public/questions", async (c) => {
    const body = await c.req.json();
    const {
      district_id, question_id, question_text,
      option_0, option_1, option_2, option_3,
      correct_answer, difficulty, category,
    } = body;

    if (!question_text || !question_id) {
      return c.json({ error: "Missing required fields" }, 400);
    }

    const result = await edgespark.db
      .insert(tables.questions)
      .values({
        districtId: district_id,
        questionId: question_id,
        questionText: question_text,
        option0: option_0,
        option1: option_1,
        option2: option_2,
        option3: option_3,
        correctAnswer: correct_answer,
        difficulty,
        category,
        createdBy: edgespark.auth.user?.id ?? null,
        createdAt: Math.floor(Date.now() / 1000),
      })
      .returning();

    return c.json({ data: result[0] }, 201);
  });

  // Update a question (public)
  app.put("/api/public/questions/:questionId", async (c) => {
    const questionId = c.req.param("questionId");
    const body = await c.req.json();
    const { question_text, option_0, option_1, option_2, option_3, correct_answer, difficulty, category } = body;

    const result = await edgespark.db
      .update(tables.questions)
      .set({
        questionText: question_text,
        option0: option_0,
        option1: option_1,
        option2: option_2,
        option3: option_3,
        correctAnswer: correct_answer,
        difficulty,
        category,
      })
      .where(eq(tables.questions.questionId, questionId))
      .returning();

    if (result.length === 0) {
      return c.json({ error: "Question not found" }, 404);
    }
    return c.json({ data: result[0] });
  });

  // Delete a question (public)
  app.delete("/api/public/questions/:questionId", async (c) => {
    const questionId = c.req.param("questionId");

    const result = await edgespark.db
      .delete(tables.questions)
      .where(eq(tables.questions.questionId, questionId))
      .returning();

    if (result.length === 0) {
      return c.json({ error: "Question not found" }, 404);
    }
    return c.json({ success: true });
  });

  // ─── Question Overrides (edited built-in questions) ─────

  // Get all overrides
  app.get("/api/public/question-overrides", async (c) => {
    const results = await edgespark.db.select().from(tables.questionOverrides);
    return c.json({ data: results });
  });

  // Upsert an override (create or update) — public
  app.put("/api/public/question-overrides/:questionId", async (c) => {
    const questionId = c.req.param("questionId");
    const body = await c.req.json();
    const {
      district_id, question_text,
      option_0, option_1, option_2, option_3,
      correct_answer, difficulty, category,
    } = body;

    if (!question_text) {
      return c.json({ error: "Missing required fields" }, 400);
    }

    // Try update first, insert if not found
    const existing = await edgespark.db
      .select()
      .from(tables.questionOverrides)
      .where(eq(tables.questionOverrides.questionId, questionId));

    if (existing.length > 0) {
      const result = await edgespark.db
        .update(tables.questionOverrides)
        .set({
          districtId: district_id,
          questionText: question_text,
          option0: option_0,
          option1: option_1,
          option2: option_2,
          option3: option_3,
          correctAnswer: correct_answer,
          difficulty,
          category,
        })
        .where(eq(tables.questionOverrides.questionId, questionId))
        .returning();
      return c.json({ data: result[0] });
    } else {
      const result = await edgespark.db
        .insert(tables.questionOverrides)
        .values({
          questionId,
          districtId: district_id,
          questionText: question_text,
          option0: option_0,
          option1: option_1,
          option2: option_2,
          option3: option_3,
          correctAnswer: correct_answer,
          difficulty,
          category,
          createdAt: Math.floor(Date.now() / 1000),
        })
        .returning();
      return c.json({ data: result[0] }, 201);
    }
  });

  // Delete an override (revert to original) — public
  app.delete("/api/public/question-overrides/:questionId", async (c) => {
    const questionId = c.req.param("questionId");
    const result = await edgespark.db
      .delete(tables.questionOverrides)
      .where(eq(tables.questionOverrides.questionId, questionId))
      .returning();
    return c.json({ success: true, deleted: result.length > 0 });
  });

  // ─── Question Deletions (deleted built-in questions) ────

  // Get all deletions
  app.get("/api/public/question-deletions", async (c) => {
    const results = await edgespark.db.select().from(tables.questionDeletions);
    return c.json({ data: results });
  });

  // Add a deletion (public)
  app.post("/api/public/question-deletions", async (c) => {
    const body = await c.req.json();
    const { question_id } = body;

    if (!question_id) {
      return c.json({ error: "Missing question_id" }, 400);
    }

    // Check for duplicates
    const existing = await edgespark.db
      .select()
      .from(tables.questionDeletions)
      .where(eq(tables.questionDeletions.questionId, question_id));

    if (existing.length > 0) {
      return c.json({ data: existing[0] });
    }

    const result = await edgespark.db
      .insert(tables.questionDeletions)
      .values({
        questionId: question_id,
        createdAt: Math.floor(Date.now() / 1000),
      })
      .returning();
    return c.json({ data: result[0] }, 201);
  });

  // Remove a deletion (restore) — public
  app.delete("/api/public/question-deletions/:questionId", async (c) => {
    const questionId = c.req.param("questionId");
    await edgespark.db
      .delete(tables.questionDeletions)
      .where(eq(tables.questionDeletions.questionId, questionId));
    return c.json({ success: true });
  });

  // ─── Deleted Custom Questions (soft-delete trash) ───────

  // Get all deleted custom questions
  app.get("/api/public/deleted-custom-questions", async (c) => {
    const results = await edgespark.db.select().from(tables.deletedCustomQuestions);
    return c.json({ data: results });
  });

  // Soft-delete a custom question (move to trash) — public
  app.post("/api/public/deleted-custom-questions", async (c) => {
    const body = await c.req.json();
    const {
      district_id, question_id, question_text,
      option_0, option_1, option_2, option_3,
      correct_answer, difficulty, category,
    } = body;

    if (!question_id || !question_text) {
      return c.json({ error: "Missing required fields" }, 400);
    }

    // Upsert: if already deleted, just return existing
    const existing = await edgespark.db
      .select()
      .from(tables.deletedCustomQuestions)
      .where(eq(tables.deletedCustomQuestions.questionId, question_id));

    if (existing.length > 0) {
      return c.json({ data: existing[0] });
    }

    const result = await edgespark.db
      .insert(tables.deletedCustomQuestions)
      .values({
        districtId: district_id,
        questionId: question_id,
        questionText: question_text,
        option0: option_0,
        option1: option_1,
        option2: option_2,
        option3: option_3,
        correctAnswer: correct_answer,
        difficulty,
        category,
        deletedAt: Math.floor(Date.now() / 1000),
      })
      .returning();
    return c.json({ data: result[0] }, 201);
  });

  // Restore a deleted custom question — public
  app.delete("/api/public/deleted-custom-questions/:questionId", async (c) => {
    const questionId = c.req.param("questionId");
    const result = await edgespark.db
      .delete(tables.deletedCustomQuestions)
      .where(eq(tables.deletedCustomQuestions.questionId, questionId))
      .returning();
    return c.json({ success: true, deleted: result.length > 0 });
  });

  // ─── Rooms (Online Multiplayer) ───────────────────────────
  //
  // The host is authoritative: it owns the game logic and writes the
  // full game state as JSON into rooms.game_state. Guests poll GET
  // /api/public/rooms/:code and render whatever the host published.
  // Guests join by appending their player into game_state.players via
  // POST /api/public/rooms/:code/join.

  const genRoomCode = () => {
    const chars = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"; // no confusing 0/O/1/I/L
    let code = "";
    for (let i = 0; i < 5; i++) code += chars[Math.floor(Math.random() * chars.length)];
    return code;
  };

  // Create a room. Body: { host_player_id, game_state }
  app.post("/api/public/rooms", async (c) => {
    const body = await c.req.json().catch(() => ({}));
    const hostPlayerId = body.host_player_id ?? null;
    const gameState = body.game_state ? JSON.stringify(body.game_state) : "{}";

    // Generate a unique code (retry a few times on collision)
    let code = genRoomCode();
    for (let attempt = 0; attempt < 5; attempt++) {
      const existing = await edgespark.db
        .select()
        .from(tables.rooms)
        .where(eq(tables.rooms.code, code));
      if (existing.length === 0) break;
      code = genRoomCode();
    }

    const result = await edgespark.db
      .insert(tables.rooms)
      .values({
        code,
        hostPlayerId,
        gameState,
        status: "waiting",
        createdAt: Math.floor(Date.now() / 1000),
      })
      .returning();

    console.log("[API] POST /api/public/rooms - created room:", code);
    return c.json({ data: { ...result[0], gameState: JSON.parse(result[0].gameState) } }, 201);
  });

  // Get a room by code (polled by all clients)
  app.get("/api/public/rooms/:code", async (c) => {
    const code = c.req.param("code").toUpperCase();
    const result = await edgespark.db
      .select()
      .from(tables.rooms)
      .where(eq(tables.rooms.code, code));

    if (result.length === 0) {
      return c.json({ error: "Room not found" }, 404);
    }
    const room = result[0];
    let parsed: any = {};
    try { parsed = JSON.parse(room.gameState); } catch { parsed = {}; }
    return c.json({ data: { ...room, gameState: parsed } });
  });

  // Join a room. Body: { player: { id, name, color } }
  app.post("/api/public/rooms/:code/join", async (c) => {
    const code = c.req.param("code").toUpperCase();
    const body = await c.req.json().catch(() => ({}));
    const player = body.player;
    if (!player || !player.id || !player.name) {
      return c.json({ error: "Missing player info" }, 400);
    }

    const result = await edgespark.db
      .select()
      .from(tables.rooms)
      .where(eq(tables.rooms.code, code));
    if (result.length === 0) {
      return c.json({ error: "Room not found" }, 404);
    }
    const room = result[0];
    if (room.status !== "waiting") {
      return c.json({ error: "Game already started" }, 409);
    }

    let state: any = {};
    try { state = JSON.parse(room.gameState); } catch { state = {}; }
    if (!Array.isArray(state.players)) state.players = [];

    // Reject duplicate id; reject taken color
    if (state.players.some((p: any) => p.id === player.id)) {
      return c.json({ error: "Already joined" }, 200);
    }
    if (state.players.some((p: any) => p.color === player.color)) {
      return c.json({ error: "Color already taken" }, 409);
    }
    if (state.players.length >= 5) {
      return c.json({ error: "Room is full" }, 409);
    }

    state.players.push({
      id: player.id,
      name: player.name,
      color: player.color,
      routeIndex: 0,
      currentDistrictId: 1,
      score: 0,
      answeredQuestions: [],
      badge: "Cadet",
    });

    const updated = await edgespark.db
      .update(tables.rooms)
      .set({ gameState: JSON.stringify(state) })
      .where(eq(tables.rooms.code, code))
      .returning();

    console.log("[API] POST /api/public/rooms/:code/join -", code, player.name);
    return c.json({ data: { ...updated[0], gameState: state } });
  });

  // Update room state (host authoritative). Body: { game_state, status? }
  app.put("/api/public/rooms/:code", async (c) => {
    const code = c.req.param("code").toUpperCase();
    const body = await c.req.json().catch(() => ({}));

    const setValues: any = {};
    if (body.game_state !== undefined) setValues.gameState = JSON.stringify(body.game_state);
    if (body.status !== undefined) setValues.status = body.status;
    if (Object.keys(setValues).length === 0) {
      return c.json({ error: "Nothing to update" }, 400);
    }

    const updated = await edgespark.db
      .update(tables.rooms)
      .set(setValues)
      .where(eq(tables.rooms.code, code))
      .returning();

    if (updated.length === 0) {
      return c.json({ error: "Room not found" }, 404);
    }
    let parsed: any = {};
    try { parsed = JSON.parse(updated[0].gameState); } catch { parsed = {}; }
    return c.json({ data: { ...updated[0], gameState: parsed } });
  });

  // Example: Get all posts
  // app.get('/api/posts', async (c) => {
  //   const allPosts = await edgespark.db.select().from(tables.posts);
  //   return c.json({ posts: allPosts });
  // });

  // Example: Get post by ID
  // app.get('/api/posts/:id', async (c) => {
  //   const id = parseInt(c.req.param('id'));
  //   const result = await edgespark.db
  //     .select()
  //     .from(tables.posts)
  //     .where(eq(tables.posts.id, id));
  //
  //   if (result.length === 0) {
  //     return c.json({ error: 'Post not found' }, 404);
  //   }
  //
  //   return c.json({ post: result[0] });
  // });

  // Example: Create post
  // app.post('/api/posts', async (c) => {
  //   const data = await c.req.json();
  //
  //   if (!data.title || !data.content) {
  //     return c.json({ error: 'Missing required fields' }, 400);
  //   }
  //
  //   await edgespark.db.insert(tables.posts).values({
  //     title: data.title,
  //     content: data.content,
  //     createdAt: new Date().toISOString()
  //   });
  //
  //   return c.json({ success: true }, 201);
  // });

  // Example: Update post
  // app.put('/api/posts/:id', async (c) => {
  //   const id = parseInt(c.req.param('id'));
  //   const data = await c.req.json();
  //
  //   await edgespark.db
  //     .update(tables.posts)
  //     .set(data)
  //     .where(eq(tables.posts.id, id));
  //
  //   return c.json({ success: true });
  // });

  // Example: Delete post
  // app.delete('/api/posts/:id', async (c) => {
  //   const id = parseInt(c.req.param('id'));
  //
  //   await edgespark.db
  //     .delete(tables.posts)
  //     .where(eq(tables.posts.id, id));
  //
  //   return c.json({ success: true });
  // });

  // Example: Upload file (type-safe bucket access)
  // app.post('/api/upload', async (c) => {
  //   const data = await c.req.arrayBuffer();
  //
  //   // Use bucket from storage_schema.ts for type safety
  //   await edgespark.storage.from(buckets.uploads).put(
  //     'files/example.txt',
  //     data,
  //     { contentType: 'text/plain' }
  //   );
  //
  //   return c.json({ success: true });
  // });

  // Example: Download file
  // app.get('/api/download', async (c) => {
  //   const path = c.req.query('path') || 'files/example.txt';
  //   const file = await edgespark.storage.from(buckets.uploads).get(path);
  //
  //   if (!file) {
  //     return c.json({ error: 'File not found' }, 404);
  //   }
  //
  //   const text = new TextDecoder().decode(file.body);
  //   return c.json({ content: text, size: file.metadata.size });
  // });

  // Example: Generate presigned upload URL
  // app.post('/api/upload-url', async (c) => {
  //   const { filename } = await c.req.json();
  //
  //   const { uploadUrl, expiresAt } = await edgespark.storage
  //     .from(buckets.uploads)
  //     .createPresignedPutUrl(`large-files/${filename}`, 3600, {
  //       contentType: 'video/mp4'
  //     });
  //
  //   return c.json({ uploadUrl, expiresAt });
  // });

  return app;
}
