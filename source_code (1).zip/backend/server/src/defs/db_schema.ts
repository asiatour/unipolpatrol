import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";

export const questions = sqliteTable("questions", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  districtId: integer("district_id").notNull(),
  questionId: text("question_id").notNull().unique(),
  questionText: text("question_text").notNull(),
  option0: text("option_0").notNull(),
  option1: text("option_1").notNull(),
  option2: text("option_2").notNull(),
  option3: text("option_3").notNull(),
  correctAnswer: integer("correct_answer").notNull(),
  difficulty: text("difficulty").notNull(),
  category: text("category").notNull(),
  createdBy: text("created_by"),
  createdAt: integer("created_at").notNull().default(0),
});
