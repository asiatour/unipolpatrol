/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'th-primary': 'var(--text-primary)',
        'th-secondary': 'var(--text-secondary)',
        'th-muted': 'var(--text-muted)',
        'th-onlight': 'var(--text-on-light)',
        'th-medium': 'var(--border-medium)',
      },
    },
  },
  plugins: [],
}