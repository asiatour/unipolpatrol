// 16 Alcaldías (Districts) of Mexico City — sequential patrol route

// ─── Question categories (point-based) ──────────────────────────
export type QuestionCategory = 'friendly' | 'directions' | 'health_safety' | 'problem_response';

export interface CategoryMeta {
  label: string;
  color: string;
  emoji: string;
}

// Categories are thematic labels only — points come from the FORMAT
export const categoryConfig: Record<QuestionCategory, CategoryMeta> = {
  friendly: { label: 'Being Friendly', color: '#3d8b4f', emoji: '😊' },
  directions: { label: 'Giving Directions', color: '#2d6bc4', emoji: '🧭' },
  health_safety: { label: 'Health and Safety', color: '#c9a825', emoji: '🛡️' },
  problem_response: { label: 'Problem Response', color: '#c43d3d', emoji: '🚨' },
};

export const categoryList = Object.keys(categoryConfig) as QuestionCategory[];

// ─── Question formats (the old "difficulty", now a question style) ──
// Easy   → simple word translation, four answer choices
// Medium → a conversation with one turn missing, four choices for that turn
// Hard   → a conversation with one missing word that players must TYPE
//          (multiple correct answers are accepted)
export type QuestionDifficulty = 'easy' | 'medium' | 'hard';

export interface FormatMeta {
  label: string;
  hint: string;
  color: string;
  emoji: string;
}

export const formatConfig: Record<QuestionDifficulty, FormatMeta> = {
  easy: {
    label: 'Translation',
    hint: 'A simple word translation with four answers — e.g. “How do you say ‘gracias’ in English?”',
    color: '#3d8b4f',
    emoji: '🟢',
  },
  medium: {
    label: 'Missing Turn',
    hint: 'A conversation with one turn missing — players pick the missing turn from four choices.',
    color: '#c9a825',
    emoji: '🟡',
  },
  hard: {
    label: 'Type the Word',
    hint: 'A conversation with one missing word — players type the word. List every accepted answer below.',
    color: '#c43d3d',
    emoji: '🔴',
  },
};

export const formatList = Object.keys(formatConfig) as QuestionDifficulty[];

// Points awarded for a correct answer — based on the question's FORMAT:
// Easy (translation) = 10, Medium (missing turn) = 20, Hard (typed word) = 30
export const difficultyPoints: Record<QuestionDifficulty, number> = {
  easy: 10,
  medium: 20,
  hard: 30,
};

// Map legacy category names (from old saved questions / backend rows)
// onto the new point-based categories so nothing breaks at runtime.
const legacyCategoryMap: Record<string, QuestionCategory> = {
  friendly: 'friendly',
  directions: 'directions',
  health_safety: 'health_safety',
  problem_response: 'problem_response',
  geography: 'directions',
  landmarks: 'friendly',
  english: 'directions',
  crimes: 'problem_response',
  misc: 'problem_response',
};

export function normalizeCategory(value: unknown): QuestionCategory {
  return legacyCategoryMap[String(value)] ?? 'problem_response';
}

export interface TriviaQuestion {
  id: string;
  // Easy: the translation prompt. Medium/Hard: the conversation text
  // (one turn per line, the gap marked with _____ for hard questions).
  question: string;
  // Easy/Medium: the four answer choices.
  // Hard: NO choices — the options hold every accepted answer instead
  // (players type the missing word; any of these is correct).
  options: string[];
  // Easy/Medium: index of the correct option. Hard: always 0.
  correctAnswer: number;
  category: QuestionCategory;
  difficulty: QuestionDifficulty;
}

// ─── Typed-answer helpers (hard questions) ───

// Hard questions have no visible choices — their options ARE the list of
// accepted answers (stored in the backend's option_0..option_3 columns,
// so no schema change was needed).
export function getAcceptedAnswers(q: TriviaQuestion): string[] {
  return q.options ?? [];
}

export function isTypingQuestion(q: TriviaQuestion): boolean {
  return q.difficulty === 'hard';
}

// Lowercase, trim, collapse spaces, drop trailing punctuation so that
// "Take a taxi!", "take a taxi" and " take a taxi " all match.
export function normalizeTyped(text: string): string {
  return text.toLowerCase().trim().replace(/\s+/g, ' ').replace(/[.,!?;:¡¿]+$/g, '');
}

// Does the player's typed word match any accepted answer?
export function checkTypedAnswer(q: TriviaQuestion, text: string): boolean {
  const typed = normalizeTyped(text);
  if (!typed) return false;
  return getAcceptedAnswers(q).some((a) => normalizeTyped(a) === typed);
}

// Safety net for very old saved data: force a valid format.
export function normalizeDifficulty(value: unknown): QuestionDifficulty {
  return value === 'medium' || value === 'hard' ? value : 'easy';
}

// Points a question is worth = its format's value
export function getQuestionPoints(q: TriviaQuestion): number {
  return difficultyPoints[normalizeDifficulty(q.difficulty)];
}

export type LevelName = 'start' | 'tourist' | 'city' | 'emergency' | 'victory';

export interface Level {
  name: LevelName;
  label: string;
  color: string;
  bgColor: string;
}

export const levels: Record<LevelName, Level> = {
  start: { name: 'start', label: 'Level 0: Start', color: '#FFFFFF', bgColor: '#F8FAFC' },
  tourist: { name: 'tourist', label: 'Level 1: Tourist English', color: '#3B82F6', bgColor: '#EFF6FF' },
  city: { name: 'city', label: 'Level 2: City Interaction', color: '#22C55E', bgColor: '#F0FDF4' },
  emergency: { name: 'emergency', label: 'Level 3: Emergency English', color: '#EAB308', bgColor: '#FEFCE8' },
  victory: { name: 'victory', label: 'Level 4: Final / Victory', color: '#EF4444', bgColor: '#FEF2F2' },
};

export interface District {
  id: number;
  name: string;
  subtitle: string;
  level: LevelName;
  color: string;
  icon: string;
  description: string;
  funFact: string;
  trivia: TriviaQuestion[];
  // Map position as percentage (for absolute positioning on map)
  mapX: number;
  mapY: number;
}

// Sequential patrol route order
export const patrolRoute = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16];

// Which transitions use special transport
export const specialTransitions: Record<number, { type: 'metro' | 'swat'; from: number; to: number }> = {};

// All built-in questions were removed — the question bank is now 100%
// custom. Teachers add their own questions per borough in the
// Question Editor (saved to localStorage + backend for sync).
export const districts: District[] = [
  // ─── Step 1: Start ─────────────────────────────────────────────
  {
    id: 1, name: "Cuauhtémoc", subtitle: "Centro Histórico", level: 'start',
    color: '#FFFFFF', icon: '🏛️',
    description: "The historic heart of Mexico City, home to the Zócalo, the National Palace, and the Metropolitan Cathedral.",
    funFact: "The name Cuauhtémoc means 'descending eagle' in Nahuatl, honoring the last Aztec emperor.",
    mapX: 50, mapY: 32,
    trivia: [],
  },
  // ─── Step 2: Poniente (Blue) ───────────────────────────────────
  {
    id: 2, name: "Azcapotzalco", subtitle: "", level: 'tourist',
    color: '#3B82F6', icon: '🏆',
    description: "A northern industrial district with a rich pre-Hispanic heritage, once the capital of the Tepanec Empire.",
    funFact: "Azcapotzalco was the capital of the powerful Tepanec Empire before the Aztecs conquered it.",
    mapX: 38, mapY: 18,
    trivia: [],
  },
  {
    id: 3, name: "Miguel Hidalgo", subtitle: "Polanco", level: 'tourist',
    color: '#3B82F6', icon: '🏰',
    description: "An upscale district featuring Chapultepec Castle, the National Museum of Anthropology, and luxury shopping on Paseo de la Reforma.",
    funFact: "Chapultepec Park is twice the size of Central Park in New York City.",
    mapX: 32, mapY: 28,
    trivia: [],
  },
  {
    id: 4, name: "Cuajimalpa", subtitle: "", level: 'tourist',
    color: '#3B82F6', icon: '🌲',
    description: "A mountainous western district that borders the State of Mexico, home to Santa Fe business district and dense forests.",
    funFact: "Cuajimalpa is home to one of the last remaining forests within Mexico City limits.",
    mapX: 16, mapY: 38,
    trivia: [],
  },
  {
    id: 5, name: "Álvaro Obregón", subtitle: "Santa Fe", level: 'tourist',
    color: '#3B82F6', icon: '🏢',
    description: "A western district with the San Ángel neighborhood and Santa Fe business district, famous for its Saturday art bazaar.",
    funFact: "The San Ángel Art Bazaar has been running since 1932 and features over 800 artists.",
    mapX: 26, mapY: 44,
    trivia: [],
  },
  {
    id: 6, name: "Magdalena Contreras", subtitle: "", level: 'tourist',
    color: '#3B82F6', icon: '🏔️',
    description: "A southern district known for the Desierto de los Leones National Park and its colonial-era Carmelite monastery.",
    funFact: "Desierto de los Leones (Desert of the Lions) is actually a forest, not a desert.",
    mapX: 22, mapY: 60,
    trivia: [],
  },
  // ─── Step 7: Sur (Green) ───────────────────────────────────────
  {
    id: 7, name: "Benito Juárez", subtitle: "Roma / Condesa", level: 'city',
    color: '#22C55E', icon: '🌳',
    description: "A modern business and residential district with parks, the World Trade Center, and the National Auditorium.",
    funFact: "The National Auditorium in Benito Juárez has been named the best venue in the world multiple times.",
    mapX: 44, mapY: 42,
    trivia: [],
  },
  {
    id: 8, name: "Coyoacán", subtitle: "", level: 'city',
    color: '#22C55E', icon: '🎨',
    description: "A bohemian neighborhood known for its colonial architecture, the Frida Kahlo Museum, and vibrant cultural scene.",
    funFact: "Frida Kahlo's famous 'Casa Azul' (Blue House) is located in Coyoacán and is now a museum.",
    mapX: 42, mapY: 52,
    trivia: [],
  },
  {
    id: 9, name: "Tlalpan", subtitle: "", level: 'city',
    color: '#22C55E', icon: '⛰️',
    description: "The largest district by area, featuring the UNAM main campus, the Pedregal lava fields, and Mount Ajusco.",
    funFact: "Tlalpan contains the Pedregal de San Ángel, a unique ecosystem formed by ancient volcanic lava flows.",
    mapX: 38, mapY: 72,
    trivia: [],
  },
  // ─── Step 10: Oriente (Yellow) ─────────────────────────────────
  {
    id: 10, name: "Xochimilco", subtitle: "", level: 'emergency',
    color: '#EAB308', icon: '🚣',
    description: "Famous for its UNESCO World Heritage canals and colorful trajinera boats, a remnant of the Aztec lake system.",
    funFact: "Xochimilco's canals are the last surviving remnants of the vast lake system that once covered the Valley of Mexico.",
    mapX: 55, mapY: 64,
    trivia: [],
  },
  {
    id: 11, name: "Milpa Alta", subtitle: "", level: 'emergency',
    color: '#EAB308', icon: '🌵',
    description: "The most rural district in the city, known for its corn and nopal cultivation, traditional festivals, and strong indigenous Nahuatl heritage.",
    funFact: "Milpa Alta produces over 50% of the nopal (cactus) consumed in all of Mexico City.",
    mapX: 62, mapY: 82,
    trivia: [],
  },
  {
    id: 12, name: "Tláhuac", subtitle: "", level: 'emergency',
    color: '#EAB308', icon: '🌾',
    description: "An eastern district known for its traditional agriculture, chinampas (floating gardens), and the Lago de los Reyes Aztecas.",
    funFact: "Tláhuac still produces crops using chinampas, an ancient Aztec farming method that predates Columbus.",
    mapX: 68, mapY: 56,
    trivia: [],
  },
  {
    id: 13, name: "Iztapalapa", subtitle: "", level: 'emergency',
    color: '#EAB308', icon: '⛪',
    description: "The most populous district in Mexico City, famous for its massive Passion Play reenactment every Easter.",
    funFact: "Iztapalapa's Passion Play is the largest in the world, with over 4,000 actors.",
    mapX: 64, mapY: 42,
    trivia: [],
  },
  // ─── Step 14: Norte (Red) ──────────────────────────────────────
  {
    id: 14, name: "Iztacalco", subtitle: "", level: 'victory',
    color: '#EF4444', icon: '🏟️',
    description: "The smallest district by area, known for its hockey stadium, textile industry, and the Iztacalco Community Museum.",
    funFact: "Iztacalco means 'House of White Salt' in Nahuatl.",
    mapX: 58, mapY: 32,
    trivia: [],
  },
  {
    id: 15, name: "Venustiano Carranza", subtitle: "Aeropuerto", level: 'victory',
    color: '#EF4444', icon: '✈️',
    description: "Home to the bustling Mercado de la Merced, Mexico City International Airport, and the historic Market of San Juan.",
    funFact: "Mercado de la Merced is the largest traditional market in Latin America.",
    mapX: 60, mapY: 24,
    trivia: [],
  },
  {
    id: 16, name: "Gustavo A. Madero", subtitle: "", level: 'victory',
    color: '#EF4444', icon: '⛪',
    description: "A densely populated northern district with the Basilica of Our Lady of Guadalupe, one of the most visited religious sites in the world.",
    funFact: "The Basilica of Guadalupe receives about 10 million visitors per year, more than the Vatican.",
    mapX: 54, mapY: 10,
    trivia: [],
  },
];

export const getDistrictById = (id: number): District | undefined => {
  return districts.find(d => d.id === id);
};
