import { districts, patrolRoute, categoryConfig, normalizeCategory, getQuestionPoints, isTypingQuestion, checkTypedAnswer, TriviaQuestion, QuestionCategory } from '../data/districts';
import { RoomGameState, RoomAction } from './roomStore';

// Question resolution reuses the same override/deleted refs as local mode
import type { CustomQuestionStore } from './useCustomQuestions';

let customRef: CustomQuestionStore[] = [];
let editedRef: Record<string, { districtId: number; question: TriviaQuestion }> = {};
let deletedRef: string[] = [];

export function setEngineQuestionRefs(
  custom: CustomQuestionStore[],
  edited: Record<string, { districtId: number; question: TriviaQuestion }>,
  deleted: string[],
) {
  customRef = custom;
  editedRef = edited;
  deletedRef = deleted;
}

function pickQuestion(districtId: number, category: QuestionCategory): TriviaQuestion | null {
  const district = districts.find((d) => d.id === districtId);
  if (!district) return null;

  const effectiveBuiltIn = district.trivia
    .filter((q) => !deletedRef.includes(q.id))
    .map((q) => (editedRef[q.id] ? editedRef[q.id].question : q));

  const pool = [
    ...effectiveBuiltIn,
    ...customRef.filter((cq) => cq.districtId === districtId).map((cq) => cq.question),
  ];

  // Prefer the chosen category; fall back to any question in the borough
  const matching = pool.filter((q) => normalizeCategory(q.category) === category);
  const finalPool = matching.length > 0 ? matching : pool;

  if (finalPool.length === 0) return null;
  return finalPool[Math.floor(Math.random() * finalPool.length)];
}

const ANSWER_TIME_MS = 30_000; // 30 seconds

// Apply a single action to the state (host-side authoritative reducer)
export function applyAction(state: RoomGameState, action: RoomAction): RoomGameState {
  const s: RoomGameState = JSON.parse(JSON.stringify(state));

  // If the timer has expired and we're in trivia phase, auto-resolve first
  if (s.phase === 'trivia' && s.timerEnd && Date.now() >= s.timerEnd) {
    return resolveRound(s);
  }

  switch (action.type) {
    case 'chooseCategory': {
      // Only the category chooser may act, and only in 'playing' phase
      if (s.phase !== 'playing') return state;
      if (action.playerId !== s.categoryChooserId) return state;

      const category = (action.payload?.category ?? 'friendly') as QuestionCategory;
      const q = pickQuestion(s.currentDistrictId, category);

      const chooser = s.players.find((p) => p.id === action.playerId);
      const district = districts.find((d) => d.id === s.currentDistrictId);

      if (!q) {
        // No questions for this borough yet — skip the round entirely
        const skipped = advanceRound(JSON.parse(JSON.stringify(s)));
        skipped.gameLog.push(
          `⚠️ No questions for ${district?.name ?? 'this borough'} yet — round skipped. Add them in the Question Editor.`,
        );
        return skipped;
      }

      s.phase = 'trivia';
      s.currentQuestion = q;
      s.currentCategory = category;
      s.answers = {};
      s.timerEnd = Date.now() + ANSWER_TIME_MS;
      s.showResult = false;

      s.gameLog.push(
        `🎯 ${chooser?.name ?? 'Player'} chose ${categoryConfig[normalizeCategory(q.category)].label} for ${district?.name ?? 'Borough #' + s.currentDistrictId}`,
      );
      return s;
    }

    case 'submitAnswer': {
      // Any player can answer during trivia phase, before timer expires
      if (s.phase !== 'trivia') return state;
      if (!s.currentQuestion) return state;
      if (s.timerEnd && Date.now() >= s.timerEnd) {
        // Timer expired — resolve
        return resolveRound(s);
      }
      // Don't allow double-answering
      if (action.playerId in s.answers) return state;

      let answerIndex = action.payload?.answerIndex as number | undefined;
      const answerText = action.payload?.answerText as string | undefined;

      if (isTypingQuestion(s.currentQuestion)) {
        // Hard questions: the player typed the missing word — check it
        // against the accepted answers (stored in question.options).
        if (typeof answerText !== 'string' || !answerText.trim()) return state;
        answerIndex = checkTypedAnswer(s.currentQuestion, answerText)
          ? s.currentQuestion.correctAnswer
          : -1;
      } else if (typeof answerIndex !== 'number') {
        return state;
      }

      s.answers[action.playerId] = answerIndex;

      const player = s.players.find((p) => p.id === action.playerId);
      const correct = answerIndex === s.currentQuestion.correctAnswer;
      // Points come from the question's format: Easy 10, Medium 20, Hard 30
      const points = correct ? getQuestionPoints(s.currentQuestion) : 0;

      if (player) {
        const newScore = player.score + points;
        let newBadge = player.badge;
        if (newScore >= 400) newBadge = 'Comisario';
        else if (newScore >= 300) newBadge = 'Inspector';
        else if (newScore >= 200) newBadge = 'Oficial';
        else if (newScore >= 100) newBadge = 'Policia';
        else newBadge = 'Cadete';
        player.score = newScore;
        player.badge = newBadge;
        player.answeredQuestions = [...player.answeredQuestions, s.currentQuestion.id];

        s.gameLog.push(
          correct
            ? `✅ ${player.name} answered correctly! +${points} pts`
            : `❌ ${player.name} answered incorrectly.`,
        );
      }

      // If all players have answered, resolve immediately
      const allAnswered = s.players.every((p) => p.id in s.answers);
      if (allAnswered) {
        return resolveRound(s);
      }

      return s;
    }

    case 'nextRound': {
      // Only valid during roundResult phase
      if (s.phase !== 'roundResult') return state;

      return advanceRound(s);
    }

    default:
      return state;
  }
}

/** Award points for correct answers and show results */
function resolveRound(s: RoomGameState): RoomGameState {
  if (s.phase !== 'trivia' || !s.currentQuestion) return s;

  // Award points to players who answered correctly (if not already awarded)
  const points = getQuestionPoints(s.currentQuestion);

  for (const player of s.players) {
    if (!(player.id in s.answers)) {
      // Player didn't answer in time
      s.gameLog.push(`⏰ ${player.name} ran out of time!`);
      continue;
    }
    // Points already awarded during submitAnswer, so nothing more to do here
  }

  s.phase = 'roundResult';
  s.showResult = true;
  s.timerEnd = null;

  const district = districts.find((d) => d.id === s.currentDistrictId);
  s.gameLog.push(`📋 Round results for ${district?.name ?? 'Borough'}:`);
  for (const player of s.players) {
    const answerIdx = s.answers[player.id];
    if (answerIdx === undefined) {
      s.gameLog.push(`  ⏰ ${player.name}: no answer`);
    } else {
      const correct = answerIdx === s.currentQuestion.correctAnswer;
      s.gameLog.push(`  ${correct ? '✅' : '❌'} ${player.name}: ${correct ? 'Correct' : 'Incorrect'}`);
    }
  }

  return s;
}

/** Advance to the next round (next borough) */
function advanceRound(s: RoomGameState): RoomGameState {
  const nextRound = s.roundNumber + 1;

  // Check if game is over (all 16 rounds done)
  if (nextRound >= patrolRoute.length) {
    s.phase = 'gameover';
    s.currentQuestion = null;
    s.showResult = false;
    s.gameLog.push('🏆 All rounds complete! Final scores:');
    // Sort players by score for final ranking
    const sorted = [...s.players].sort((a, b) => b.score - a.score);
    sorted.forEach((p, i) => {
      s.gameLog.push(`  ${i + 1}. ${p.name} — ${p.score} pts (${p.badge})`);
    });
    return s;
  }

  // Advance all players to next district
  s.players = s.players.map((p) => ({
    ...p,
    routeIndex: p.routeIndex + 1,
    currentDistrictId: patrolRoute[p.routeIndex + 1],
  }));

  s.roundNumber = nextRound;
  s.currentDistrictId = patrolRoute[nextRound];

  // Rotate the question-category chooser (next player in line)
  const currentChooserIdx = s.players.findIndex((p) => p.id === s.categoryChooserId);
  const nextChooserIdx = (currentChooserIdx + 1) % s.players.length;
  s.categoryChooserId = s.players[nextChooserIdx].id;

  // Reset for next round
  s.phase = 'playing';
  s.currentQuestion = null;
  s.currentCategory = null;
  s.answers = {};
  s.timerEnd = null;
  s.showResult = false;

  const district = districts.find((d) => d.id === s.currentDistrictId);
  const chooser = s.players[nextChooserIdx];
  s.gameLog.push(
    ` round ${nextRound + 1}/16 — ${district?.name ?? 'Borough #' + s.currentDistrictId} — ${chooser.name} chooses a category`,
  );

  return s;
}

// Host drains the queue: apply all unprocessed actions in order.
// Returns { state, changed }.
export function drainQueue(state: RoomGameState): { state: RoomGameState; changed: boolean } {
  if (!state.actionQueue || state.actionQueue.length === 0) {
    // Even with no actions, check if timer expired
    if (state.phase === 'trivia' && state.timerEnd && Date.now() >= state.timerEnd) {
      const resolved = resolveRound(JSON.parse(JSON.stringify(state)));
      return { state: resolved, changed: true };
    }
    return { state, changed: false };
  }

  let s = state;
  let changed = false;
  const processed = new Set(s.processedActions || []);

  for (const action of s.actionQueue) {
    if (processed.has(action.id)) continue;
    const next = applyAction(s, action);
    if (next !== s) {
      s = next;
      changed = true;
    }
    processed.add(action.id);
  }

  // Check if timer expired after processing actions
  if (s.phase === 'trivia' && s.timerEnd && Date.now() >= s.timerEnd) {
    const resolved = resolveRound(s);
    if (resolved !== s) {
      s = resolved;
      changed = true;
    }
  }

  if (changed || (s.actionQueue && s.actionQueue.length > 0)) {
    s = JSON.parse(JSON.stringify(s));
    s.actionQueue = [];
    s.processedActions = Array.from(processed).slice(-50);
    s.updatedAt = Date.now();
    changed = true;
  }

  return { state: s, changed };
}

/** Create the initial game state when the host starts the game */
export function startGameState(state: RoomGameState): RoomGameState {
  const s: RoomGameState = JSON.parse(JSON.stringify(state));
  s.phase = 'playing';
  s.roundNumber = 0;
  s.currentDistrictId = patrolRoute[0];
  s.categoryChooserId = s.players[0]?.id ?? null;
  s.currentQuestion = null;
  s.currentCategory = null;
  s.answers = {};
  s.timerEnd = null;
  s.showResult = false;

  // Initialize all players at the first district
  s.players = s.players.map((p) => ({
    ...p,
    routeIndex: 0,
    currentDistrictId: patrolRoute[0],
    score: 0,
    answeredQuestions: [],
    badge: 'Cadete',
  }));

  s.gameLog = [
    '🚨 Mission briefing: All cadets patrol together through 16 districts!',
    `Round 1/16 — ${districts.find((d) => d.id === patrolRoute[0])?.name}`,
    `${s.players[0]?.name ?? 'Player 1'} chooses the question category.`,
  ];
  s.updatedAt = Date.now();
  return s;
}
