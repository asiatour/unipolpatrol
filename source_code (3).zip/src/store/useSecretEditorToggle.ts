import { useCallback, useRef } from 'react';

/**
 * Secret question-editor toggle: five rapid clicks on the badge logo
 * (each within ~2 seconds of the previous one) fire `onSecret`.
 * Returns a click handler to attach to the badge.
 */
export default function useSecretEditorToggle(onSecret: () => void) {
  const clicksRef = useRef(0);
  const timerRef = useRef<number | null>(null);

  return useCallback(() => {
    clicksRef.current += 1;
    if (timerRef.current !== null) window.clearTimeout(timerRef.current);

    if (clicksRef.current >= 5) {
      clicksRef.current = 0;
      onSecret();
      return;
    }

    timerRef.current = window.setTimeout(() => {
      clicksRef.current = 0;
      timerRef.current = null;
    }, 2000);
  }, [onSecret]);
}
