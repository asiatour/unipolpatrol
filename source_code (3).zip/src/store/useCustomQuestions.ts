import { create } from 'zustand';
import { TriviaQuestion, districts, normalizeCategory, normalizeDifficulty } from '../data/districts';
import { client } from '../api/client';

// Storage keys were bumped to -v2 as part of the full question-bank reset
// (October 2026): every old question was wiped from the backend and the old
// keys are intentionally abandoned so stale localStorage copies don't
// reappear. All districts start empty for the new game.
const STORAGE_KEY = 'unipol-patrol-custom-questions-v2';
const OVERRIDES_KEY = 'unipol-patrol-edited-questions-v2';
const DELETED_KEY = 'unipol-patrol-deleted-questions-v2';

// All backend routes (reads and writes) live under /api/public/* —
// no login is required anywhere. The teacher sign-in gate was removed.

export interface CustomQuestionStore {
  districtId: number;
  question: TriviaQuestion;
}

// One flattened entry of the "live" question bank: built-in questions with
// the latest edits applied (minus deleted ones) plus all custom questions.
export interface EffectiveQuestion extends TriviaQuestion {
  districtId: number;
  districtName: string;
  source: 'built-in' | 'custom';
  edited: boolean;
}

// ─── localStorage helpers ───

// Questions saved before the category rework carry old category names
// (geography, landmarks, …). Normalize them to the new point-based ones
// and make sure every question has a valid format (difficulty).
function normalizeQuestion<T extends TriviaQuestion>(q: T): T {
  return { ...q, category: normalizeCategory(q.category), difficulty: normalizeDifficulty(q.difficulty) };
}

function loadCustomQuestions(): CustomQuestionStore[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed: CustomQuestionStore[] = JSON.parse(raw);
    return parsed.map((cq) => ({ ...cq, question: normalizeQuestion(cq.question) }));
  } catch {
    return [];
  }
}

function loadEditedQuestions(): Record<string, { districtId: number; question: TriviaQuestion }> {
  try {
    const raw = localStorage.getItem(OVERRIDES_KEY);
    if (!raw) return {};
    const parsed: Record<string, { districtId: number; question: TriviaQuestion }> = JSON.parse(raw);
    const out: typeof parsed = {};
    for (const [qId, entry] of Object.entries(parsed)) {
      out[qId] = { ...entry, question: normalizeQuestion(entry.question) };
    }
    return out;
  } catch {
    return {};
  }
}

function loadDeletedIds(): string[] {
  try {
    const raw = localStorage.getItem(DELETED_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveCustomQuestions(questions: CustomQuestionStore[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(questions));
}

function saveEditedQuestions(overrides: Record<string, { districtId: number; question: TriviaQuestion }>) {
  localStorage.setItem(OVERRIDES_KEY, JSON.stringify(overrides));
}

function saveDeletedIds(ids: string[]) {
  localStorage.setItem(DELETED_KEY, JSON.stringify(ids));
}

// ─── Backend API helpers ───

async function fetchBackendQuestions(): Promise<CustomQuestionStore[]> {
  try {
    const res = await client.api.fetch('/api/public/questions');
    if (!res.ok) return [];
    const json = await res.json();
    if (!json.data) return [];
    return json.data.map((row: any) => ({
      districtId: row.district_id ?? row.districtId,
      question: {
        id: row.question_id ?? row.questionId,
        question: row.question_text ?? row.questionText,
        // .filter(Boolean) drops the empty-string padding used for hard
        // questions so accepted-answer lists come back clean.
        options: [row.option_0 ?? row.option0, row.option_1 ?? row.option1, row.option_2 ?? row.option2, row.option_3 ?? row.option3].filter(Boolean),
        correctAnswer: row.correct_answer ?? row.correctAnswer,
        difficulty: normalizeDifficulty(row.difficulty),
        category: normalizeCategory(row.category),
      } as TriviaQuestion,
    }));
  } catch {
    return [];
  }
}

async function fetchBackendOverrides(): Promise<Record<string, { districtId: number; question: TriviaQuestion }>> {
  try {
    const res = await client.api.fetch('/api/public/question-overrides');
    if (!res.ok) return {};
    const json = await res.json();
    if (!json.data) return {};
    const result: Record<string, { districtId: number; question: TriviaQuestion }> = {};
    for (const row of json.data) {
      const qId = row.question_id ?? row.questionId;
      result[qId] = {
        districtId: row.district_id ?? row.districtId,
        question: {
          id: qId,
          question: row.question_text ?? row.questionText,
          // .filter(Boolean) drops the empty-string padding used for hard
        // questions so accepted-answer lists come back clean.
        options: [row.option_0 ?? row.option0, row.option_1 ?? row.option1, row.option_2 ?? row.option2, row.option_3 ?? row.option3].filter(Boolean),
          correctAnswer: row.correct_answer ?? row.correctAnswer,
          difficulty: normalizeDifficulty(row.difficulty),
          category: normalizeCategory(row.category),
        } as TriviaQuestion,
      };
    }
    return result;
  } catch {
    return {};
  }
}

async function fetchBackendDeletions(): Promise<string[]> {
  try {
    const res = await client.api.fetch('/api/public/question-deletions');
    if (!res.ok) return [];
    const json = await res.json();
    if (!json.data) return [];
    return json.data.map((row: any) => row.question_id ?? row.questionId);
  } catch {
    return [];
  }
}

async function createBackendQuestion(districtId: number, question: TriviaQuestion): Promise<boolean> {
  try {
    const res = await client.api.fetch('/api/public/questions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        district_id: districtId,
        question_id: question.id,
        question_text: question.question,
        // Hard (typing) questions store accepted answers in options[0..n]
        // and may have fewer than four — pad with empty strings so the
        // backend's NOT NULL option columns never reject the insert.
        option_0: question.options[0] ?? '',
        option_1: question.options[1] ?? '',
        option_2: question.options[2] ?? '',
        option_3: question.options[3] ?? '',
        correct_answer: question.correctAnswer,
        difficulty: question.difficulty,
        category: question.category,
      }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

async function updateBackendQuestion(questionId: string, districtId: number, question: TriviaQuestion): Promise<boolean> {
  try {
    const res = await client.api.fetch(`/api/public/questions/${encodeURIComponent(questionId)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        question_text: question.question,
        // Hard (typing) questions store accepted answers in options[0..n]
        // and may have fewer than four — pad with empty strings so the
        // backend's NOT NULL option columns never reject the insert.
        option_0: question.options[0] ?? '',
        option_1: question.options[1] ?? '',
        option_2: question.options[2] ?? '',
        option_3: question.options[3] ?? '',
        correct_answer: question.correctAnswer,
        difficulty: question.difficulty,
        category: question.category,
      }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

async function deleteBackendQuestion(questionId: string): Promise<boolean> {
  try {
    const res = await client.api.fetch(`/api/public/questions/${encodeURIComponent(questionId)}`, {
      method: 'DELETE',
    });
    return res.ok;
  } catch {
    return false;
  }
}

async function saveBackendOverride(questionId: string, districtId: number, question: TriviaQuestion): Promise<boolean> {
  try {
    const res = await client.api.fetch(`/api/public/question-overrides/${encodeURIComponent(questionId)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        district_id: districtId,
        question_text: question.question,
        // Hard (typing) questions store accepted answers in options[0..n]
        // and may have fewer than four — pad with empty strings so the
        // backend's NOT NULL option columns never reject the insert.
        option_0: question.options[0] ?? '',
        option_1: question.options[1] ?? '',
        option_2: question.options[2] ?? '',
        option_3: question.options[3] ?? '',
        correct_answer: question.correctAnswer,
        difficulty: question.difficulty,
        category: question.category,
      }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

async function deleteBackendOverride(questionId: string): Promise<boolean> {
  try {
    const res = await client.api.fetch(`/api/public/question-overrides/${encodeURIComponent(questionId)}`, {
      method: 'DELETE',
    });
    return res.ok;
  } catch {
    return false;
  }
}

async function saveBackendDeletion(questionId: string): Promise<boolean> {
  try {
    const res = await client.api.fetch('/api/public/question-deletions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ question_id: questionId }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

async function deleteBackendDeletion(questionId: string): Promise<boolean> {
  try {
    const res = await client.api.fetch(`/api/public/question-deletions/${encodeURIComponent(questionId)}`, {
      method: 'DELETE',
    });
    return res.ok;
  } catch {
    return false;
  }
}

async function fetchBackendDeletedCustomQuestions(): Promise<CustomQuestionStore[]> {
  try {
    const res = await client.api.fetch('/api/public/deleted-custom-questions');
    if (!res.ok) return [];
    const json = await res.json();
    if (!json.data) return [];
    return json.data.map((row: any) => ({
      districtId: row.district_id ?? row.districtId,
      question: {
        id: row.question_id ?? row.questionId,
        question: row.question_text ?? row.questionText,
        // .filter(Boolean) drops the empty-string padding used for hard
        // questions so accepted-answer lists come back clean.
        options: [row.option_0 ?? row.option0, row.option_1 ?? row.option1, row.option_2 ?? row.option2, row.option_3 ?? row.option3].filter(Boolean),
        correctAnswer: row.correct_answer ?? row.correctAnswer,
        difficulty: normalizeDifficulty(row.difficulty),
        category: normalizeCategory(row.category),
      } as TriviaQuestion,
    }));
  } catch {
    return [];
  }
}

async function saveBackendDeletedCustomQuestion(districtId: number, question: TriviaQuestion): Promise<boolean> {
  try {
    const res = await client.api.fetch('/api/public/deleted-custom-questions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        district_id: districtId,
        question_id: question.id,
        question_text: question.question,
        // Hard (typing) questions store accepted answers in options[0..n]
        // and may have fewer than four — pad with empty strings so the
        // backend's NOT NULL option columns never reject the insert.
        option_0: question.options[0] ?? '',
        option_1: question.options[1] ?? '',
        option_2: question.options[2] ?? '',
        option_3: question.options[3] ?? '',
        correct_answer: question.correctAnswer,
        difficulty: question.difficulty,
        category: question.category,
      }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

async function deleteBackendDeletedCustomQuestion(questionId: string): Promise<boolean> {
  try {
    const res = await client.api.fetch(`/api/public/deleted-custom-questions/${encodeURIComponent(questionId)}`, {
      method: 'DELETE',
    });
    return res.ok;
  } catch {
    return false;
  }
}

// ─── Zustand store ───

interface CustomQuestionsState {
  customQuestions: CustomQuestionStore[];
  editedQuestions: Record<string, { districtId: number; question: TriviaQuestion }>;
  deletedIds: string[];
  deletedCustomQuestions: CustomQuestionStore[];
  synced: boolean;

  addQuestion: (districtId: number, question: TriviaQuestion) => void;
  updateQuestion: (questionId: string, districtId: number, updated: TriviaQuestion) => void;
  deleteQuestion: (questionId: string) => void;
  restoreDeletedQuestion: (questionId: string) => void;
  saveBuiltInOverride: (questionId: string, districtId: number, updated: TriviaQuestion) => void;
  deleteBuiltInQuestion: (questionId: string) => void;
  restoreBuiltInQuestion: (questionId: string) => void;
  revertBuiltInOverride: (questionId: string) => void;
  getQuestionsForDistrict: (districtId: number) => TriviaQuestion[];
  getEffectiveQuestions: () => EffectiveQuestion[];
  clearAll: () => void;
  mergeBackendQuestions: () => void;
}

export const useCustomQuestions = create<CustomQuestionsState>((set, get) => ({
  customQuestions: loadCustomQuestions(),
  editedQuestions: loadEditedQuestions(),
  deletedIds: loadDeletedIds(),
  deletedCustomQuestions: [],
  synced: false,

  addQuestion: (districtId, question) => {
    set((state) => {
      const next = [...state.customQuestions, { districtId, question }];
      saveCustomQuestions(next);
      return { customQuestions: next };
    });
    createBackendQuestion(districtId, question);
  },

  updateQuestion: (questionId, districtId, updated) => {
    set((state) => {
      const next = state.customQuestions.map((cq) =>
        cq.question.id === questionId
          ? { districtId, question: updated }
          : cq
      );
      saveCustomQuestions(next);
      return { customQuestions: next };
    });
    updateBackendQuestion(questionId, districtId, updated);
  },

  deleteQuestion: (questionId) => {
    set((state) => {
      const removed = state.customQuestions.find((cq) => cq.question.id === questionId);
      if (!removed) return state;
      const next = state.customQuestions.filter((cq) => cq.question.id !== questionId);
      const nextDeleted = [...state.deletedCustomQuestions, removed];
      saveCustomQuestions(next);
      return { customQuestions: next, deletedCustomQuestions: nextDeleted };
    });
    // Find the question data to send to backend
    const state = get();
    const removed = state.deletedCustomQuestions.find((cq) => cq.question.id === questionId);
    if (removed) {
      saveBackendDeletedCustomQuestion(removed.districtId, removed.question);
    }
    deleteBackendQuestion(questionId);
  },

  restoreDeletedQuestion: (questionId) => {
    set((state) => {
      const restored = state.deletedCustomQuestions.find((cq) => cq.question.id === questionId);
      if (!restored) return state;
      const nextDeleted = state.deletedCustomQuestions.filter((cq) => cq.question.id !== questionId);
      const nextCustom = [...state.customQuestions, restored];
      saveCustomQuestions(nextCustom);
      return { customQuestions: nextCustom, deletedCustomQuestions: nextDeleted };
    });
    // Re-create in the main questions table
    const state = get();
    const restored = state.customQuestions.find((cq) => cq.question.id === questionId);
    if (restored) {
      createBackendQuestion(restored.districtId, restored.question);
    }
    deleteBackendDeletedCustomQuestion(questionId);
  },

  saveBuiltInOverride: (questionId, districtId, updated) => {
    set((state) => {
      const next = { ...state.editedQuestions, [questionId]: { districtId, question: updated } };
      saveEditedQuestions(next);
      return { editedQuestions: next };
    });
    saveBackendOverride(questionId, districtId, updated);
  },

  deleteBuiltInQuestion: (questionId) => {
    set((state) => {
      if (state.deletedIds.includes(questionId)) return state;
      const next = [...state.deletedIds, questionId];
      saveDeletedIds(next);
      return { deletedIds: next };
    });
    saveBackendDeletion(questionId);
  },

  restoreBuiltInQuestion: (questionId) => {
    set((state) => {
      const next = state.deletedIds.filter((id) => id !== questionId);
      saveDeletedIds(next);
      return { deletedIds: next };
    });
    deleteBackendDeletion(questionId);
  },

  revertBuiltInOverride: (questionId) => {
    set((state) => {
      const next = { ...state.editedQuestions };
      delete next[questionId];
      saveEditedQuestions(next);
      return { editedQuestions: next };
    });
    deleteBackendOverride(questionId);
  },

  getQuestionsForDistrict: (districtId) => {
    return get().customQuestions
      .filter((cq) => cq.districtId === districtId)
      .map((cq) => cq.question);
  },

  // Full live question bank in patrol-route order:
  // built-in (latest edited version, deleted ones removed) + custom questions.
  getEffectiveQuestions: () => {
    const state = get();
    const result: EffectiveQuestion[] = [];
    for (const district of districts) {
      for (const q of district.trivia) {
        if (state.deletedIds.includes(q.id)) continue;
        const override = state.editedQuestions[q.id];
        const live = override ? override.question : q;
        result.push({
          ...live,
          districtId: district.id,
          districtName: district.name,
          source: 'built-in',
          edited: !!override,
        });
      }
      for (const cq of state.customQuestions.filter((c) => c.districtId === district.id)) {
        result.push({
          ...cq.question,
          districtId: district.id,
          districtName: district.name,
          source: 'custom',
          edited: false,
        });
      }
    }
    // Safety net: custom questions pointing at an unknown district go last
    for (const cq of state.customQuestions.filter((c) => !districts.some((d) => d.id === c.districtId))) {
      result.push({
        ...cq.question,
        districtId: cq.districtId,
        districtName: `District ${cq.districtId}`,
        source: 'custom',
        edited: false,
      });
    }
    return result;
  },

  clearAll: () => {
    set(() => {
      saveCustomQuestions([]);
      return { customQuestions: [] };
    });
  },

  mergeBackendQuestions: () => {
    Promise.all([
      fetchBackendQuestions(),
      fetchBackendOverrides(),
      fetchBackendDeletions(),
      fetchBackendDeletedCustomQuestions(),
    ]).then(([backendQuestions, backendOverrides, backendDeletions, backendDeletedCustom]) => {
      let localOnlyToPush: CustomQuestionStore[] = [];
      set((state) => {
        // Merge custom questions: backend is source of truth, keep local-only ones
        // (e.g. questions whose backend POST failed or were added offline) so a
        // sync never silently drops them.
        let mergedCustom = state.customQuestions;
        if (backendQuestions.length > 0) {
          const backendIds = new Set(backendQuestions.map((cq) => cq.question.id));
          const merged = [...backendQuestions];
          for (const local of state.customQuestions) {
            if (!backendIds.has(local.question.id)) {
              merged.push(local);
            }
          }
          mergedCustom = merged;
          // Track local-only questions so they can be re-pushed below
          localOnlyToPush = merged.filter((cq) => !backendIds.has(cq.question.id));
        }

        // Merge overrides: backend is source of truth, keep local-only ones
        const mergedOverrides = { ...backendOverrides };
        for (const [qId, localOverride] of Object.entries(state.editedQuestions)) {
          if (!mergedOverrides[qId]) {
            mergedOverrides[qId] = localOverride;
          }
        }

        // Merge deletions: backend is source of truth, keep local-only ones
        const mergedDeletionsSet = new Set(backendDeletions);
        for (const localId of state.deletedIds) {
          mergedDeletionsSet.add(localId);
        }
        const mergedDeletions = [...mergedDeletionsSet];

        // Merge deleted custom questions: backend is source of truth, keep local-only
        const mergedDeletedCustom = [...backendDeletedCustom];
        const backendIds = new Set(backendDeletedCustom.map((cq) => cq.question.id));
        for (const local of state.deletedCustomQuestions) {
          if (!backendIds.has(local.question.id)) {
            mergedDeletedCustom.push(local);
          }
        }

        saveCustomQuestions(mergedCustom);
        saveEditedQuestions(mergedOverrides);
        saveDeletedIds(mergedDeletions);

        return {
          customQuestions: mergedCustom,
          editedQuestions: mergedOverrides,
          deletedIds: mergedDeletions,
          deletedCustomQuestions: mergedDeletedCustom,
          synced: true,
        };
      });

      // Rescue local-only questions by re-pushing them to the backend
      // (e.g. hard questions whose first save failed before the
      // option-padding fix, or adds made while offline). Failed pushes
      // are simply retried on the next sync.
      for (const cq of localOnlyToPush) {
        createBackendQuestion(cq.districtId, cq.question);
      }
    });
  },
}));
