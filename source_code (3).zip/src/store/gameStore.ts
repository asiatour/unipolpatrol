import { create } from 'zustand';
import { districts, patrolRoute, getQuestionPoints, checkTypedAnswer, TriviaQuestion, QuestionCategory } from '../data/districts';
import { CustomQuestionStore } from './useCustomQuestions';

let customQuestionsRef: CustomQuestionStore[] = [];
let editedQuestionsRef: Record<string, { districtId: number; question: TriviaQuestion }> = {};
let deletedIdsRef: string[] = [];

export function setCustomQuestionsRef(ref: CustomQuestionStore[], edited: Record<string, { districtId: number; question: TriviaQuestion }>, deleted: string[]) {
  customQuestionsRef = ref;
  editedQuestionsRef = edited;
  deletedIdsRef = deleted;
}

export type PlayerColor = 'car' | 'moto' | 'horse' | 'foot' | 'bike';

export interface Player {
  id: number | string;
  name: string;
  color: PlayerColor;
  routeIndex: number; // 0-15, position in patrolRoute
  currentDistrictId: number;
  score: number;
  answeredQuestions: string[];
  badge: string;
}

export interface GameState {
  players: Player[];
  currentPlayerIndex: number;
  phase: 'setup' | 'playing' | 'trivia' | 'gameover';

  currentQuestion: TriviaQuestion | null;
  selectedAnswer: number | null;
  typedAnswer: string | null;
  showResult: boolean;
  isCorrect: boolean | null;

  gameLog: string[];
  isTraining: boolean;
  highScore: number;

  // ─── Online mode bridge ───
  // When set, the action methods dispatch to the server instead of
  // mutating local state. The synced remote state is pushed back in via
  // syncFromRemote(). myTurn gates whether the local user may act.
  onlineDispatch: ((type: 'begin' | 'answer' | 'next' | 'skip', payload?: any) => void) | null;
  isOnline: boolean;
  myTurn: boolean;

  addPlayer: (name: string, color: PlayerColor) => void;
  removePlayer: (id: number) => void;
  startGame: () => void;
  setTrainingMode: (training: boolean) => void;
  beginQuestion: (category: QuestionCategory) => void;
  answerQuestion: (answerIndex: number | null, answerText?: string) => void;
  nextTurn: () => void;
  resetGame: () => void;
  skipTrivia: () => void;

  setOnlineBridge: (dispatch: GameState['onlineDispatch'], myTurn: boolean) => void;
  syncFromRemote: (partial: Partial<GameState>) => void;
}

export const useGameStore = create<GameState>((set, get) => ({
  players: [],
  currentPlayerIndex: 0,
  phase: 'setup',
  currentQuestion: null,
  selectedAnswer: null,
  typedAnswer: null,
  showResult: false,
  isCorrect: null,
  gameLog: [],
  isTraining: false,
  highScore: parseInt(localStorage.getItem('cdmx-patrol-highscore') || '0', 10),
  onlineDispatch: null,
  isOnline: false,
  myTurn: false,

  setOnlineBridge: (dispatch, myTurn) => set({ onlineDispatch: dispatch, isOnline: !!dispatch, myTurn }),
  syncFromRemote: (partial) => set(partial as any),

  setTrainingMode: (training) => set({ isTraining: training }),

  addPlayer: (name, color) => {
    set((state) => ({
      players: [...state.players, {
        id: state.players.length + 1,
        name,
        color,
        routeIndex: 0,
        currentDistrictId: patrolRoute[0],
        score: 0,
        answeredQuestions: [],
        badge: 'Cadet',
      }]
    }));
  },

  removePlayer: (id) => {
    set((state) => ({
      players: state.players.filter(p => p.id !== id)
    }));
  },

  startGame: () => {
    const state = get();
    if (state.players.length === 0) return;
    set({
      phase: 'playing',
      currentPlayerIndex: 0,
      gameLog: ['🚨 Mission briefing: Complete all 16 districts from Cuauhtémoc to Azcapotzalco!', `${state.players[0].name} begins the patrol at Cuauhtémoc.`],
    });
  },

  beginQuestion: (category) => {
    const state = get();
    if (state.isOnline) {
      if (state.myTurn && state.onlineDispatch) state.onlineDispatch('begin', { category });
      return;
    }
    const player = state.players[state.currentPlayerIndex];
    if (!player) return;
    const district = districts.find(d => d.id === player.currentDistrictId);
    if (!district) return;

    // Build the effective question list for this district:
    // Start with built-in questions, apply overrides, filter deleted
    const effectiveBuiltIn = district.trivia
      .filter(q => !deletedIdsRef.includes(q.id))
      .map(q => editedQuestionsRef[q.id] ? editedQuestionsRef[q.id].question : q);

    const districtQuestions = [
      ...effectiveBuiltIn,
      ...customQuestionsRef.filter(cq => cq.districtId === district.id).map(cq => cq.question),
    ];

    // Prefer questions from the chosen category; fall back to any question
    // in the borough if that category has none.
    const matching = districtQuestions.filter(q => q.category === category);
    const pool = matching.length > 0 ? matching : districtQuestions;

    if (pool.length === 0) {
      // No questions for this borough yet — stay in 'playing' so the
      // ActionBar can show the "add questions" hint.
      return;
    }

    const idx = Math.floor(Math.random() * pool.length);

    set({
      phase: 'trivia',
      currentQuestion: pool[idx],
      selectedAnswer: null,
      typedAnswer: null,
      showResult: false,
      isCorrect: null,
    });
  },

  answerQuestion: (answerIndex: number | null, answerText?: string) => {
    const state = get();
    if (state.isOnline) {
      if (state.myTurn && state.onlineDispatch) state.onlineDispatch('answer', { answerIndex, answerText });
      return;
    }
    if (!state.currentQuestion || state.showResult) return;

    // Typed answers (hard questions) are checked against the accepted answers
    const correct = typeof answerText === 'string'
      ? checkTypedAnswer(state.currentQuestion, answerText)
      : answerIndex === state.currentQuestion.correctAnswer;
    const player = state.players[state.currentPlayerIndex];
    const district = districts.find(d => d.id === player.currentDistrictId);

    // Points come from the question's format: Easy 10, Medium 20, Hard 30
    const points = correct ? getQuestionPoints(state.currentQuestion) : 0;

    const newScore = player.score + points;
    let newBadge = player.badge;
    if (newScore >= 400) newBadge = 'Comisario';
    else if (newScore >= 300) newBadge = 'Inspector';
    else if (newScore >= 200) newBadge = 'Oficial';
    else if (newScore >= 100) newBadge = 'Policia';
    else newBadge = 'Cadete';

    set((s) => ({
      selectedAnswer: answerIndex,
      typedAnswer: answerText ?? null,
      showResult: true,
      isCorrect: correct,
      players: s.players.map((p, i) => {
        if (i !== s.currentPlayerIndex) return p;
        return {
          ...p,
          score: newScore,
          answeredQuestions: [...p.answeredQuestions, state.currentQuestion!.id],
          badge: newBadge,
        };
      }),
      gameLog: [...s.gameLog,
        correct
          ? `✅ ${player.name} answered correctly about ${district?.name}! +${points} pts`
          : typeof answerText === 'string'
            ? `❌ ${player.name} typed “${answerText}” — incorrect about ${district?.name}.`
            : `❌ ${player.name} answered incorrectly about ${district?.name}.`
      ]
    }));
  },

  skipTrivia: () => {
    const state = get();
    if (state.isOnline) {
      if (state.myTurn && state.onlineDispatch) state.onlineDispatch('skip');
      return;
    }
    set((s) => ({
      showResult: true,
      isCorrect: false,
      gameLog: [...s.gameLog, `${s.players[s.currentPlayerIndex].name} skipped the question.`]
    }));
  },

  nextTurn: () => {
    const state = get();
    if (state.isOnline) {
      if (state.myTurn && state.onlineDispatch) state.onlineDispatch('next');
      return;
    }
    const player = state.players[state.currentPlayerIndex];
    let updatedPlayers = [...state.players];

    // Only a correct answer moves the player on. In Training Range a wrong
    // answer keeps them in the same borough so they can fix the error and retry.
    if (state.isCorrect) {
      const nextRouteIdx = player.routeIndex + 1;
      if (nextRouteIdx < patrolRoute.length) {
        updatedPlayers = updatedPlayers.map((p, i) => {
          if (i !== state.currentPlayerIndex) return p;
          return {
            ...p,
            routeIndex: nextRouteIdx,
            currentDistrictId: patrolRoute[nextRouteIdx],
          };
        });
      }
    }

    // Check if this player finished
    const updatedPlayer = updatedPlayers[state.currentPlayerIndex];
    // A player only completes the route by answering the final question correctly
    const reachedEnd = state.isCorrect && updatedPlayer.routeIndex >= patrolRoute.length - 1;

    if (reachedEnd) {
      updatedPlayers = updatedPlayers.map((p, i) => {
        if (i !== state.currentPlayerIndex) return p;
        return { ...p, badge: 'Inspector' };
      });
    }

    // Check if all players completed
    const allDone = updatedPlayers.every(p => p.routeIndex >= patrolRoute.length - 1);

    if (allDone) {
      // Save high score for training mode
      const playerScore = updatedPlayers[state.currentPlayerIndex].score;
      const prevHigh = parseInt(localStorage.getItem('cdmx-patrol-highscore') || '0', 10);
      if (playerScore > prevHigh) {
        localStorage.setItem('cdmx-patrol-highscore', String(playerScore));
      }
      set({
        players: updatedPlayers,
        phase: 'gameover',
        highScore: Math.max(playerScore, prevHigh),
        gameLog: [...state.gameLog, '🏆 All cadets completed the patrol! Mission accomplished!']
      });
      return;
    }

    // Next player
    let nextIdx = (state.currentPlayerIndex + 1) % updatedPlayers.length;
    let safety = 0;
    while (updatedPlayers[nextIdx].routeIndex >= patrolRoute.length - 1 && safety < updatedPlayers.length) {
      nextIdx = (nextIdx + 1) % updatedPlayers.length;
      safety++;
    }

    const nextPlayer = updatedPlayers[nextIdx];

    const currentDistrictName = districts.find(d => d.id === player.currentDistrictId)?.name;
    const logMsg = reachedEnd
      ? `🎖️ ${player.name} completed the patrol route!`
      : state.isTraining && !state.isCorrect
        ? `🔒 Training rule: correct answer required to move on — ${player.name} stays in ${currentDistrictName}. Fix the error and try again!`
        : '';

    set({
      players: updatedPlayers,
      currentPlayerIndex: nextIdx,
      phase: 'playing',
      currentQuestion: null,
      selectedAnswer: null,
      typedAnswer: null,
      showResult: false,
      isCorrect: null,
      gameLog: logMsg
        ? [...state.gameLog, logMsg, `${nextPlayer.name}'s turn — at ${districts.find(d => d.id === nextPlayer.currentDistrictId)?.name}`]
        : [...state.gameLog, `${nextPlayer.name}'s turn — at ${districts.find(d => d.id === nextPlayer.currentDistrictId)?.name}`],
    });
  },

  resetGame: () => {
    set({
      players: [],
      currentPlayerIndex: 0,
      phase: 'setup',
      currentQuestion: null,
      selectedAnswer: null,
      typedAnswer: null,
      showResult: false,
      isCorrect: null,
      gameLog: [],
      onlineDispatch: null,
      isOnline: false,
      isTraining: false,
      myTurn: false,
    });
  },
}));
