import { useEffect, useState } from 'react';
import { districts, categoryConfig, categoryList, formatConfig, formatList, difficultyPoints, isTypingQuestion, normalizeDifficulty, TriviaQuestion } from '../data/districts';
import { useCustomQuestions, CustomQuestionStore } from '../store/useCustomQuestions';
import { motion, AnimatePresence } from 'framer-motion';

interface QuestionEditorProps {
  onClose: () => void;
}

export default function QuestionEditor({ onClose }: QuestionEditorProps) {
  const {
    customQuestions, editedQuestions, deletedIds, deletedCustomQuestions, synced,
    addQuestion, updateQuestion, deleteQuestion, restoreDeletedQuestion,
    saveBuiltInOverride, deleteBuiltInQuestion, restoreBuiltInQuestion,
    revertBuiltInOverride, getEffectiveQuestions,
  } = useCustomQuestions();
  const [selectedDistrict, setSelectedDistrict] = useState<number>(1);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingBuiltIn, setEditingBuiltIn] = useState<boolean>(false);
  const [showAddForm, setShowAddForm] = useState(false);
  const [showDeleted, setShowDeleted] = useState<boolean>(false);

  // Pull the latest questions from the backend each time the editor opens
  // so newly added questions show up immediately.
  useEffect(() => {
    useCustomQuestions.getState().mergeBackendQuestions();
  }, []);

  const [formQuestion, setFormQuestion] = useState('');
  const [formOptions, setFormOptions] = useState(['', '', '', '']);
  const [formCorrect, setFormCorrect] = useState(0);
  const [formDifficulty, setFormDifficulty] = useState<TriviaQuestion['difficulty']>('easy');
  const [formCategory, setFormCategory] = useState<TriviaQuestion['category']>('friendly');

  const district = districts.find(d => d.id === selectedDistrict);
  const builtInQuestions = district?.trivia || [];
  const customForDistrict = customQuestions.filter(cq => cq.districtId === selectedDistrict);

  const resetForm = () => {
    setFormQuestion('');
    setFormOptions(['', '', '', '']);
    setFormCorrect(0);
    setFormDifficulty('easy');
    setFormCategory('friendly');
    setEditingId(null);
    setEditingBuiltIn(false);
    setShowAddForm(false);
  };

  const cancelEdit = () => {
    resetForm();
  };

  const startEditCustom = (cq: CustomQuestionStore) => {
    setEditingId(cq.question.id);
    setEditingBuiltIn(false);
    setFormQuestion(cq.question.question);
    setFormOptions([...cq.question.options, '', '', '', ''].slice(0, 4));
    setFormCorrect(cq.question.correctAnswer);
    setFormDifficulty(normalizeDifficulty(cq.question.difficulty));
    setFormCategory(cq.question.category);
  };

  const startEditBuiltIn = (q: TriviaQuestion) => {
    const override = editedQuestions[q.id];
    const source = override ? override.question : q;
    setEditingId(q.id);
    setEditingBuiltIn(true);
    setFormQuestion(source.question);
    setFormOptions([...source.options, '', '', '', ''].slice(0, 4));
    setFormCorrect(source.correctAnswer);
    setFormDifficulty(normalizeDifficulty(source.difficulty));
    setFormCategory(source.category);
  };

  const handleSubmit = () => {
    if (!formQuestion.trim()) return;

    const trimmedOptions = formOptions.map(o => o.trim());
    const isTyping = formDifficulty === 'hard';

    // Easy/Medium need all four choices filled.
    // Hard (typing) questions have no choices — the options hold the
    // accepted answers, and only the first one is required.
    if (isTyping) {
      if (!trimmedOptions[0]) return;
    } else if (trimmedOptions.some(o => !o)) {
      return;
    }

    const questionData: TriviaQuestion = {
      id: editingId || `custom-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      question: formQuestion.trim(),
      options: isTyping ? trimmedOptions.filter(Boolean) : trimmedOptions,
      correctAnswer: isTyping ? 0 : formCorrect,
      difficulty: formDifficulty,
      category: formCategory,
    };

    if (editingBuiltIn && editingId) {
      saveBuiltInOverride(editingId, selectedDistrict, questionData);
    } else if (editingId) {
      updateQuestion(editingId, selectedDistrict, questionData);
    } else {
      addQuestion(selectedDistrict, questionData);
    }

    resetForm();
  };

  const handleDeleteCustom = (questionId: string) => {
    deleteQuestion(questionId);
  };

  const handleDeleteBuiltIn = (questionId: string) => {
    deleteBuiltInQuestion(questionId);
  };

  const handleRevert = (questionId: string) => {
    revertBuiltInOverride(questionId);
  };

  const handleRestore = (questionId: string) => {
    restoreBuiltInQuestion(questionId);
  };

  const startAddNew = () => {
    resetForm();
    setShowAddForm(true);
  };

  const totalCustom = customQuestions.length;
  const totalDeletedCustom = deletedCustomQuestions.length;

  /* ── Export live question bank (JSON / CSV) ── */
  const handleExport = (format: 'json' | 'csv') => {
    const questions = getEffectiveQuestions();
    const stamp = new Date().toISOString().slice(0, 10);
    let content: string;
    let mime: string;
    let ext: string;

    if (format === 'json') {
      content = JSON.stringify(
        {
          exportedAt: new Date().toISOString(),
          note: 'Live question bank with all edits applied. correctAnswer is the 0-based index; correctAnswerText is the answer text. For hard (type-the-word) questions the options ARE the accepted answers and correctAnswer is 0.',
          total: questions.length,
          questions: questions.map(q => ({
            id: q.id,
            districtId: q.districtId,
            district: q.districtName,
            question: q.question,
            options: q.options,
            correctAnswer: q.correctAnswer,
            correctAnswerText: q.options[q.correctAnswer] ?? '',
            difficulty: q.difficulty,
            category: q.category,
            source: q.source,
            edited: q.edited,
          })),
        },
        null,
        2
      );
      mime = 'application/json';
      ext = 'json';
    } else {
      const esc = (v: string | number) => `"${String(v).replace(/"/g, '""')}"`;
      const header = ['district_id', 'district', 'question', 'option_a', 'option_b', 'option_c', 'option_d', 'correct_answer', 'correct_answer_text', 'difficulty', 'category', 'source', 'edited'];
      const rows = questions.map(q => [
        q.districtId, q.districtName, q.question,
        q.options[0] ?? '', q.options[1] ?? '', q.options[2] ?? '', q.options[3] ?? '',
        String.fromCharCode(65 + q.correctAnswer), q.options[q.correctAnswer] ?? '',
        q.difficulty, q.category, q.source, q.edited ? 'yes' : 'no',
      ]);
      content = [header.map(esc).join(','), ...rows.map(r => r.map(esc).join(','))].join('\n');
      mime = 'text/csv';
      ext = 'csv';
    }

    const blob = new Blob([content], { type: `${mime};charset=utf-8` });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `unipol-patrol-questions-${stamp}.${ext}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const zoneColors: Record<string, string> = {
    start: '#e8e4df',
    tourist: '#2d6bc4',
    city: '#3d8b4f',
    emergency: '#c9a825',
    victory: '#c43d3d',
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-black/70 backdrop-blur-md flex items-center justify-center p-4"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      {/* data-theme="dark": the panel is always dark, so pin the dark text
          palette here — otherwise light mode renders dark-on-dark text. */}
      <motion.div
        initial={{ scale: 0.95, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.95, y: 20 }}
        data-theme="dark"
        className="bg-[#1e1c18] rounded-2xl shadow-2xl w-full max-w-3xl max-h-[90vh] overflow-hidden flex flex-col border border-white/[0.06]"
      >
        {/* Header */}
        <div className="px-5 py-4 border-b border-white/[0.06] flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-th-primary">📝 Question Editor</h2>
            <p className="text-xs text-th-secondary mt-0.5">
              <button
                onClick={() => setShowDeleted(false)}
                title="Back to the question editor"
                className={`transition-colors ${showDeleted ? 'text-th-primary underline decoration-dotted underline-offset-2 hover:text-[#c8956c]' : 'hover:text-th-primary'}`}
              >
                {totalCustom} custom
              </button>
              {totalDeletedCustom > 0 && (
                <button
                  onClick={() => setShowDeleted(!showDeleted)}
                  className={`ml-2 font-bold underline transition-colors ${showDeleted ? 'text-[#c43d3d]' : 'text-[#c43d3d]/70 hover:text-[#c43d3d]'}`}
                >
                  {totalDeletedCustom} in trash
                </button>
              )}
              {synced && <span className="ml-2 text-green-400/60">✓ synced</span>}
            </p>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => handleExport('json')}
              title="Download all questions (with your latest edits applied) as JSON"
              className="h-8 px-2.5 rounded-lg bg-white/[0.06] hover:bg-[#c8956c]/20 text-[11px] font-bold text-th-secondary hover:text-[#c8956c] transition-all"
            >
              ⬇ JSON
            </button>
            <button
              onClick={() => handleExport('csv')}
              title="Download all questions (with your latest edits applied) as CSV for Excel/Sheets"
              className="h-8 px-2.5 rounded-lg bg-white/[0.06] hover:bg-[#c8956c]/20 text-[11px] font-bold text-th-secondary hover:text-[#c8956c] transition-all"
            >
              ⬇ CSV
            </button>
            <button
              onClick={() => showDeleted ? setShowDeleted(false) : onClose()}
              className="w-8 h-8 rounded-full bg-white/[0.06] hover:bg-white/[0.1] flex items-center justify-center text-th-secondary hover:text-th-primary font-bold transition-all"
            >
              ×
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-hidden flex flex-col md:flex-row min-h-0">
          {showDeleted ? (
            /* ── Deleted Custom Questions View ── */
            <div className="flex-1 overflow-y-auto p-4">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setShowDeleted(false)}
                    className="text-xs px-2 py-1 rounded bg-white/[0.06] text-th-secondary hover:text-th-primary transition-colors"
                  >
                    ← Back
                  </button>
                  <h3 className="font-bold text-sm text-[#c43d3d]">🗑️ Deleted Custom Questions ({totalDeletedCustom})</h3>
                </div>
              </div>
              {deletedCustomQuestions.length === 0 ? (
                <p className="text-xs text-th-muted text-center py-8">No deleted custom questions.</p>
              ) : (
                <div className="space-y-2">
                  {deletedCustomQuestions.map(cq => (
                    <div key={cq.question.id} className="rounded-xl border border-[#c43d3d]/10 bg-[#c43d3d]/[0.03] p-3">
                      <div className="flex items-start justify-between gap-2">
                        <p className="text-xs font-bold text-th-secondary leading-snug flex-1 line-through">{cq.question.question}</p>
                        <button
                          onClick={() => restoreDeletedQuestion(cq.question.id)}
                          className="text-[10px] px-2 py-0.5 rounded bg-[#3d8b4f]/20 text-[#5aab6f] hover:bg-[#3d8b4f]/30 font-bold transition-colors flex-shrink-0"
                        >
                          Restore
                        </button>
                      </div>
                      <div className="mt-2">
                        {isTypingQuestion(cq.question) ? (
                          <div className="flex flex-wrap gap-1">
                            {cq.question.options.map((opt, idx) => (
                              <span key={idx} className="text-[10px] px-2 py-1 rounded bg-[#3d8b4f]/10 text-[#5aab6f] font-bold">✓ {opt}</span>
                            ))}
                          </div>
                        ) : (
                          <div className="grid grid-cols-2 gap-1">
                            {cq.question.options.map((opt, idx) => (
                              <p key={idx} className={`text-[10px] px-2 py-1 rounded ${idx === cq.question.correctAnswer ? 'bg-[#3d8b4f]/10 text-[#5aab6f] font-bold' : 'bg-white/[0.02] text-th-secondary'}`}>
                                {String.fromCharCode(65 + idx)}. {opt}
                              </p>
                            ))}
                          </div>
                        )}
                      </div>
                      <div className="flex gap-2 mt-2">
                        <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-[#c43d3d]/10 text-[#c43d3d] font-bold">{categoryConfig[cq.question.category]?.label ?? cq.question.category}</span>
                        <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-white/[0.04] text-th-muted font-bold">District {cq.districtId}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ) : (
          /* ── Normal Editor View ── */
          <>
          {/* Left: District selector */}
          <div className="w-full md:w-48 border-b md:border-b-0 md:border-r border-white/[0.06] overflow-y-auto flex-shrink-0">
            <div className="p-2 space-y-0.5">
              {districts.map(d => {
                const customCount = customQuestions.filter(cq => cq.districtId === d.id).length;
                const editedCount = Object.values(editedQuestions).filter(o => o.districtId === d.id).length;
                const deletedCount = d.trivia.filter(q => deletedIds.includes(q.id)).length;
                const modifiedCount = customCount + editedCount + deletedCount;
                const zoneColor = zoneColors[d.level] || '#c8956c';
                return (
                  <button
                    key={d.id}
                    onClick={() => { setSelectedDistrict(d.id); resetForm(); }}
                    className={`w-full text-left px-3 py-2 rounded-lg text-xs font-medium transition-all flex items-center gap-2 ${
                      selectedDistrict === d.id
                        ? 'bg-white/[0.06] border border-white/[0.08] text-th-primary'
                        : 'text-th-secondary hover:bg-white/[0.03]'
                    }`}
                  >
                    <span
                      className="w-5 h-5 rounded-full flex items-center justify-center text-white text-[9px] font-bold flex-shrink-0"
                      style={{ backgroundColor: zoneColor }}
                    >
                      {d.id}
                    </span>
                    <span className="truncate">{d.name}</span>
                    {modifiedCount > 0 && (
                      <span
                        className="ml-auto text-[9px] px-1.5 py-0.5 rounded-full font-bold flex-shrink-0"
                        style={{ backgroundColor: 'rgba(200,149,108,0.15)', color: '#c8956c' }}
                      >
                        {modifiedCount}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right: Questions list + add form */}
          <div className="flex-1 overflow-y-auto p-4 min-h-0">
            {/* District header */}
            <div className="flex items-center gap-2 mb-4">
              <div
                className="w-7 h-7 rounded-full flex items-center justify-center text-white text-xs font-bold"
                style={{ backgroundColor: district ? (zoneColors[district.level] || '#c8956c') : '#c8956c' }}
              >
                {selectedDistrict}
              </div>
              <div>
                <h3 className="font-bold text-sm text-th-primary">{district?.name}</h3>
                <p className="text-[10px] text-th-secondary">
                  {builtInQuestions.length} built-in · {customForDistrict.length} custom
                </p>
              </div>
            </div>

            {/* Empty borough hint */}
            {builtInQuestions.length === 0 && customForDistrict.length === 0 && (
              <div className="rounded-xl border border-dashed border-white/[0.08] p-4 mb-4 text-center">
                <p className="text-xs text-th-secondary leading-relaxed">
                  📝 No questions for this borough yet.<br />
                  Add your first custom question below — points are set by the category.
                </p>
              </div>
            )}

            {/* Built-in questions */}
            {builtInQuestions.length > 0 && (
              <div className="mb-4">
                <p className="text-[10px] font-bold text-th-muted uppercase tracking-wider mb-2">Built-in Questions</p>
                <div className="space-y-2">
                  {builtInQuestions.map(q => {
                    const isDeleted = deletedIds.includes(q.id);
                    const override = editedQuestions[q.id];
                    const isBeingEdited = editingId === q.id && editingBuiltIn;
                    return (
                      <QuestionCard
                        key={q.id}
                        question={override ? override.question : q}
                        builtIn
                        isDeleted={isDeleted}
                        isEdited={!!override}
                        isBeingEdited={isBeingEdited}
                        onEdit={() => startEditBuiltIn(q)}
                        onDelete={() => handleDeleteBuiltIn(q.id)}
                        onRestore={() => handleRestore(q.id)}
                        onRevert={() => handleRevert(q.id)}
                        onCancelEdit={cancelEdit}
                        formQuestion={formQuestion}
                        setFormQuestion={setFormQuestion}
                        formOptions={formOptions}
                        setFormOptions={setFormOptions}
                        formCorrect={formCorrect}
                        setFormCorrect={setFormCorrect}
                        formDifficulty={formDifficulty}
                        setFormDifficulty={setFormDifficulty}
                        formCategory={formCategory}
                        setFormCategory={setFormCategory}
                        onSubmit={handleSubmit}
                      />
                    );
                  })}
                </div>
              </div>
            )}

            {/* Custom questions */}
            {customForDistrict.length > 0 && (
              <div className="mb-4">
                <p className="text-[10px] font-bold uppercase tracking-wider mb-2" style={{ color: '#c8956c' }}>Your Custom Questions</p>
                <div className="space-y-2">
                  {customForDistrict.map(cq => {
                    const isBeingEdited = editingId === cq.question.id && !editingBuiltIn;
                    return (
                      <QuestionCard
                        key={cq.question.id}
                        question={cq.question}
                        isBeingEdited={isBeingEdited}
                        onEdit={() => startEditCustom(cq)}
                        onDelete={() => handleDeleteCustom(cq.question.id)}
                        onCancelEdit={cancelEdit}
                        formQuestion={formQuestion}
                        setFormQuestion={setFormQuestion}
                        formOptions={formOptions}
                        setFormOptions={setFormOptions}
                        formCorrect={formCorrect}
                        setFormCorrect={setFormCorrect}
                        formDifficulty={formDifficulty}
                        setFormDifficulty={setFormDifficulty}
                        formCategory={formCategory}
                        setFormCategory={setFormCategory}
                        onSubmit={handleSubmit}
                      />
                    );
                  })}
                </div>
              </div>
            )}

            {/* Deleted built-in notice */}
            {builtInQuestions.filter(q => deletedIds.includes(q.id)).length > 0 && (
              <div className="mb-4">
                <p className="text-[10px] font-bold uppercase tracking-wider mb-2 text-[#c43d3d]/60">Deleted Built-in</p>
                <div className="space-y-2">
                  {builtInQuestions.filter(q => deletedIds.includes(q.id)).map(q => (
                    <div key={q.id} className="rounded-xl border border-[#c43d3d]/10 bg-[#c43d3d]/[0.03] p-3 opacity-50">
                      <div className="flex items-start justify-between gap-2">
                        <p className="text-xs font-bold text-th-secondary leading-snug flex-1 line-through">{q.question}</p>
                        <button
                          onClick={() => handleRestore(q.id)}
                          className="text-[10px] px-2 py-0.5 rounded bg-[#3d8b4f]/20 text-[#5aab6f] hover:bg-[#3d8b4f]/30 font-bold transition-colors flex-shrink-0"
                        >
                          Restore
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Add New Question Form (inline) */}
            <AnimatePresence>
              {showAddForm ? (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="overflow-hidden"
                >
                  <div className="bg-white/[0.03] rounded-xl border border-[#c8956c]/20 p-4 mt-4">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="font-bold text-sm text-[#c8956c]">Add New Question</h4>
                      <button onClick={resetForm} className="text-xs text-th-secondary hover:text-th-primary">Cancel</button>
                    </div>
                    <InlineForm
                      formQuestion={formQuestion}
                      setFormQuestion={setFormQuestion}
                      formOptions={formOptions}
                      setFormOptions={setFormOptions}
                      formCorrect={formCorrect}
                      setFormCorrect={setFormCorrect}
                      formDifficulty={formDifficulty}
                      setFormDifficulty={setFormDifficulty}
                      formCategory={formCategory}
                      setFormCategory={setFormCategory}
                      onSubmit={handleSubmit}
                      submitLabel="Add Question"
                    />
                  </div>
                </motion.div>
              ) : (
                <button
                  onClick={startAddNew}
                  className="w-full py-3 border-2 border-dashed border-white/[0.08] rounded-xl text-th-muted hover:border-[#c8956c]/30 hover:text-[#c8956c]/60 text-xs font-bold transition-all mt-4"
                >
                  + Add New Question
                </button>
              )}
            </AnimatePresence>
          </div>
          </>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}

/* ─── Inline Form (shared between add + edit) ──────────────────── */

function InlineForm({
  formQuestion, setFormQuestion,
  formOptions, setFormOptions,
  formCorrect, setFormCorrect,
  formDifficulty, setFormDifficulty,
  formCategory, setFormCategory,
  onSubmit, submitLabel,
}: {
  formQuestion: string;
  setFormQuestion: (v: string) => void;
  formOptions: string[];
  setFormOptions: (v: string[]) => void;
  formCorrect: number;
  setFormCorrect: (v: number) => void;
  formDifficulty: TriviaQuestion['difficulty'];
  setFormDifficulty: (v: TriviaQuestion['difficulty']) => void;
  formCategory: TriviaQuestion['category'];
  setFormCategory: (v: TriviaQuestion['category']) => void;
  onSubmit: () => void;
  submitLabel: string;
}) {
  const isTyping = formDifficulty === 'hard';
  const isTranslation = formDifficulty === 'easy';

  return (
    <>
      {/* Question format */}
      <div className="mb-3">
        <label className="text-[11px] font-bold text-th-secondary mb-1 block">Question Format</label>
        <div className="grid grid-cols-3 gap-1.5">
          {formatList.map(d => {
            const meta = formatConfig[d];
            const active = formDifficulty === d;
            return (
              <button
                key={d}
                onClick={() => setFormDifficulty(d)}
                className="py-2 rounded-lg text-[10px] font-bold transition-all flex flex-col items-center gap-0.5"
                style={
                  active
                    ? { backgroundColor: `${meta.color}30`, border: `1px solid ${meta.color}60`, color: meta.color }
                    : { backgroundColor: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.06)', color: 'rgba(245,240,235,0.6)' }
                }
              >
                <span>{meta.emoji} {d === 'easy' ? 'Easy' : d === 'medium' ? 'Medium' : 'Hard'}</span>
                <span className="font-medium opacity-80">{meta.label}</span>
                <span className="opacity-70">+{difficultyPoints[d]} pts</span>
              </button>
            );
          })}
        </div>
        <p className="text-[10px] text-th-muted mt-1.5 leading-relaxed">{formatConfig[formDifficulty].hint}</p>
      </div>

      {/* Question / conversation */}
      <div className="mb-3">
        <label className="text-[11px] font-bold text-th-secondary mb-1 block">
          {isTranslation ? 'Question' : 'Conversation'}
        </label>
        <textarea
          value={formQuestion}
          onChange={(e) => setFormQuestion(e.target.value)}
          placeholder={
            isTranslation
              ? 'How do you say “gracias” in English?'
              : isTyping
                ? 'A: Excuse me, how do I get to the Zócalo?\nB: Go straight two blocks and _____.'
                : 'A: Excuse me, where is the nearest metro station?\nB: _____\nA: Thank you so much!'
          }
          rows={3}
          className="w-full bg-white/[0.04] border border-white/[0.06] rounded-lg px-3 py-2 text-sm text-white placeholder-white/20 focus:outline-none focus:ring-1 focus:ring-[#c8956c]/50 resize-none"
        />
        {!isTranslation && (
          <p className="text-[10px] text-th-muted mt-1">One speaker per line. For Hard questions, mark the gap with _____ (five underscores).</p>
        )}
      </div>

      {isTyping ? (
        /* ── Hard: accepted answers instead of choices ── */
        <div className="mb-3">
          <label className="text-[11px] font-bold text-th-secondary mb-1 block">Accepted Answers</label>
          <div className="space-y-1.5">
            {/* Example answers shown as placeholders: one taxi phrasing per field */}
            {['take a taxi', 'grab a taxi', 'hail a taxi', 'go by taxi'].map((example, idx) => (
              <input
                key={idx}
                type="text"
                value={formOptions[idx]}
                onChange={(e) => {
                  const newOpts = [...formOptions];
                  newOpts[idx] = e.target.value;
                  setFormOptions(newOpts);
                }}
                placeholder={idx === 0 ? `Required — e.g. ${example}` : `Also accept (optional) — e.g. ${example}`}
                className="w-full bg-white/[0.04] border border-white/[0.06] rounded-lg px-3 py-1.5 text-xs text-white placeholder-white/20 focus:outline-none focus:ring-1 focus:ring-[#c8956c]/50"
              />
            ))}
          </div>
          <p className="text-[10px] text-th-muted mt-1.5">Players type the missing word — list every answer you want to accept. Matching ignores capitals and punctuation.</p>
        </div>
      ) : (
        <>
          {/* Options */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mb-3">
            {formOptions.map((opt, idx) => (
              <div key={idx} className="flex items-center gap-2">
                <button
                  onClick={() => setFormCorrect(idx)}
                  className={`w-6 h-6 rounded-full flex-shrink-0 text-[10px] font-bold border-2 transition-all ${
                    formCorrect === idx
                      ? 'bg-[#3d8b4f] border-[#3d8b4f] text-white'
                      : 'bg-white/[0.04] border-white/[0.08] text-th-secondary hover:border-white/20'
                  }`}
                >
                  {String.fromCharCode(65 + idx)}
                </button>
                <input
                  type="text"
                  value={opt}
                  onChange={(e) => {
                    const newOpts = [...formOptions];
                    newOpts[idx] = e.target.value;
                    setFormOptions(newOpts);
                  }}
                  placeholder={isTranslation ? `Answer ${String.fromCharCode(65 + idx)}...` : `Turn ${String.fromCharCode(65 + idx)}...`}
                  className="flex-1 bg-white/[0.04] border border-white/[0.06] rounded-lg px-3 py-1.5 text-xs text-white placeholder-white/20 focus:outline-none focus:ring-1 focus:ring-[#c8956c]/50"
                />
              </div>
            ))}
          </div>
          <p className="text-[10px] text-th-muted mb-3">Click a letter to mark the correct answer (green = correct)</p>
        </>
      )}

      {/* Category */}
      <div className="mb-3">
        <label className="text-[11px] font-bold text-th-secondary mb-1 block">Category</label>
        <div className="grid grid-cols-2 gap-1.5">
          {categoryList.map(c => {
            const meta = categoryConfig[c];
            const active = formCategory === c;
            return (
              <button
                key={c}
                onClick={() => setFormCategory(c)}
                className="py-2 rounded-lg text-[11px] font-bold transition-all flex items-center justify-center gap-1.5"
                style={
                  active
                    ? { backgroundColor: `${meta.color}30`, border: `1px solid ${meta.color}60`, color: meta.color }
                    : { backgroundColor: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.06)', color: 'rgba(245,240,235,0.6)' }
                }
              >
                <span>{meta.emoji}</span>
                <span>{meta.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Submit */}
      <button
        onClick={onSubmit}
        disabled={!formQuestion.trim() || (isTyping ? !formOptions[0].trim() : formOptions.some(o => !o.trim()))}
        className="w-full py-2 btn-primary disabled:bg-white/[0.04] disabled:text-white/20 disabled:cursor-not-allowed rounded-lg text-sm transition-all"
      >
        {submitLabel}
      </button>
    </>
  );
}

/* ─── Question Card ────────────────────────────────────────────── */

function QuestionCard({
  question, builtIn, isDeleted, isEdited, isBeingEdited,
  onEdit, onDelete, onRestore, onRevert, onCancelEdit,
  formQuestion, setFormQuestion, formOptions, setFormOptions,
  formCorrect, setFormCorrect, formDifficulty, setFormDifficulty,
  formCategory, setFormCategory, onSubmit,
}: {
  question: TriviaQuestion;
  builtIn?: boolean;
  isDeleted?: boolean;
  isEdited?: boolean;
  isBeingEdited?: boolean;
  onEdit?: () => void;
  onDelete?: () => void;
  onRestore?: () => void;
  onRevert?: () => void;
  onCancelEdit?: () => void;
  formQuestion?: string;
  setFormQuestion?: (v: string) => void;
  formOptions?: string[];
  setFormOptions?: (v: string[]) => void;
  formCorrect?: number;
  setFormCorrect?: (v: number) => void;
  formDifficulty?: TriviaQuestion['difficulty'];
  setFormDifficulty?: (v: TriviaQuestion['difficulty']) => void;
  formCategory?: TriviaQuestion['category'];
  setFormCategory?: (v: TriviaQuestion['category']) => void;
  onSubmit?: () => void;
}) {
  const meta = categoryConfig[question.category];
  const fmt = formatConfig[normalizeDifficulty(question.difficulty)];
  const typing = isTypingQuestion(question);

  return (
    <div className={`rounded-xl border p-3 transition-all ${
      builtIn
        ? isDeleted
          ? 'bg-white/[0.01] border-white/[0.03] opacity-40'
          : 'bg-white/[0.02] border-white/[0.04]'
        : 'bg-[#c8956c]/[0.04] border-[#c8956c]/10'
    } ${isBeingEdited ? '!border-[#c8956c]/30 !bg-[#c8956c]/[0.06]' : ''}`}>
      {isBeingEdited && formQuestion !== undefined && setFormQuestion !== undefined && formOptions !== undefined && setFormOptions !== undefined && formCorrect !== undefined && setFormCorrect !== undefined && formDifficulty !== undefined && setFormDifficulty !== undefined && formCategory !== undefined && setFormCategory !== undefined && onSubmit !== undefined && onCancelEdit !== undefined ? (
        /* ── Inline Edit Mode ── */
        <div>
          <div className="flex items-center justify-between mb-3">
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#c8956c]">Editing Question</span>
            <button onClick={onCancelEdit} className="text-[10px] px-2 py-0.5 rounded bg-white/[0.06] text-th-secondary hover:text-th-primary transition-colors">
              Cancel
            </button>
          </div>
          <InlineForm
            formQuestion={formQuestion}
            setFormQuestion={setFormQuestion}
            formOptions={formOptions}
            setFormOptions={setFormOptions}
            formCorrect={formCorrect}
            setFormCorrect={setFormCorrect}
            formDifficulty={formDifficulty}
            setFormDifficulty={setFormDifficulty}
            formCategory={formCategory}
            setFormCategory={setFormCategory}
            onSubmit={onSubmit}
            submitLabel="Save Changes"
          />
        </div>
      ) : (
        /* ── Read-Only Mode ── */
        <>
          <div className="flex items-start justify-between gap-2 mb-2">
            <p className={`text-xs font-bold leading-snug flex-1 whitespace-pre-line ${isDeleted ? 'text-th-secondary line-through' : 'text-th-primary'}`}>
              {question.question}
            </p>
            <div className="flex gap-1 flex-shrink-0">
              {builtIn && isDeleted && onRestore && (
                <button onClick={onRestore} className="text-[10px] px-2 py-0.5 rounded bg-[#3d8b4f]/20 text-[#5aab6f] hover:bg-[#3d8b4f]/30 font-bold transition-colors">
                  Restore
                </button>
              )}
              {!isDeleted && builtIn && isEdited && onRevert && (
                <button onClick={onRevert} className="text-[10px] px-2 py-0.5 rounded bg-[#c9a825]/20 text-[#e0c040] hover:bg-[#c9a825]/30 font-bold transition-colors">
                  Revert
                </button>
              )}
              {!isDeleted && onEdit && (
                <button onClick={onEdit} className="text-[10px] px-2 py-0.5 rounded bg-[#2d6bc4]/20 text-[#4a8ae0] hover:bg-[#2d6bc4]/30 font-bold transition-colors">
                  Edit
                </button>
              )}
              {!isDeleted && onDelete && (
                <button onClick={onDelete} className="text-[10px] px-2 py-0.5 rounded bg-[#c43d3d]/20 text-[#e05555] hover:bg-[#c43d3d]/30 font-bold transition-colors">
                  Del
                </button>
              )}
            </div>
          </div>
          {typing ? (
            /* Hard questions: options hold the accepted answers */
            <div className="flex flex-wrap gap-1 mb-1.5">
              {question.options.map((opt, idx) => (
                <span key={idx} className="text-[10px] px-2 py-1 rounded bg-[#3d8b4f]/10 text-[#5aab6f] font-bold">
                  ✓ {opt}
                </span>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-1 mb-1.5">
              {question.options.map((opt, idx) => (
                <p key={idx} className={`text-[10px] px-2 py-1 rounded ${
                  idx === question.correctAnswer
                    ? 'bg-[#3d8b4f]/10 text-[#5aab6f] font-bold'
                    : 'bg-white/[0.02] text-th-secondary'
                }`}>
                  {String.fromCharCode(65 + idx)}. {opt}
                </p>
              ))}
            </div>
          )}
          <div className="flex gap-2 flex-wrap">
            <span
              className="text-[9px] px-1.5 py-0.5 rounded-full font-bold"
              style={{ backgroundColor: `${meta?.color ?? '#c8956c'}20`, color: meta?.color ?? '#c8956c' }}
            >
              {meta?.label ?? question.category}
            </span>
            <span
              className="text-[9px] px-1.5 py-0.5 rounded-full font-bold"
              style={{ backgroundColor: `${fmt.color}20`, color: fmt.color }}
              title={fmt.hint}
            >
              {fmt.emoji} {fmt.label} · +{difficultyPoints[normalizeDifficulty(question.difficulty)]} pts
            </span>
            {isEdited && !isDeleted && (
              <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-[#c9a825]/20 text-[#e0c040] font-bold">
                edited
              </span>
            )}
          </div>
        </>
      )}
    </div>
  );
}
