import { useState, useEffect } from 'react';
import { useGameStore } from '../store/gameStore';
import { districts, categoryConfig, formatConfig, normalizeCategory, isTypingQuestion, getAcceptedAnswers, getQuestionPoints } from '../data/districts';
import { motion, AnimatePresence } from 'framer-motion';

const zoneColors: Record<string, string> = {
  start: '#e8e4df',
  tourist: '#2d6bc4',
  city: '#3d8b4f',
  emergency: '#c9a825',
  victory: '#c43d3d',
};

export default function TriviaCard() {
  const { currentQuestion, answerQuestion, showResult, selectedAnswer, typedAnswer, isCorrect, nextTurn, phase, currentPlayerIndex, players, isTraining } = useGameStore();
  const [typedText, setTypedText] = useState('');

  // Fresh input for each new question
  useEffect(() => {
    setTypedText('');
  }, [currentQuestion?.id]);

  if (phase !== 'trivia' || !currentQuestion) return null;

  const player = players[currentPlayerIndex];
  const district = districts.find(d => d.id === player?.currentDistrictId);
  const zoneColor = district ? zoneColors[district.level] : '#c8956c';
  const meta = categoryConfig[normalizeCategory(currentQuestion.category)];
  const fmt = formatConfig[currentQuestion.difficulty];
  const points = getQuestionPoints(currentQuestion);
  const typing = isTypingQuestion(currentQuestion);
  const accepted = typing ? getAcceptedAnswers(currentQuestion) : [];

  const handleTypedSubmit = () => {
    if (!typedText.trim() || showResult) return;
    answerQuestion(null, typedText.trim());
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.96 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: -20, scale: 0.96 }}
        transition={{ type: 'spring', stiffness: 300, damping: 25 }}
        className="w-full max-w-md mx-auto"
      >
        <div className="glass-card rounded-2xl overflow-hidden">
          {/* Header */}
          <div
            className="px-4 py-3 flex items-center justify-between"
            style={{ backgroundColor: `${zoneColor}20`, borderBottom: `1px solid ${zoneColor}20` }}
          >
            <div className="flex items-center gap-2">
              <span className="text-sm">{district?.icon} {meta.emoji} <span className="text-th-secondary text-[10px] font-bold">{meta.label}</span></span>
              <span className="text-th-primary font-bold text-xs">#{district?.id} {district?.name}</span>
            </div>
            <div className="flex items-center gap-2">
              <span
                className="px-2 py-0.5 rounded text-[10px] font-bold border"
                style={{ backgroundColor: `${meta.color}15`, color: meta.color, borderColor: `${meta.color}40` }}
              >
                {meta.label}
              </span>
              <span
                className="px-1.5 py-0.5 rounded text-[9px] font-bold border"
                style={{ backgroundColor: `${fmt.color}15`, color: fmt.color, borderColor: `${fmt.color}40` }}
                title={fmt.hint}
              >
                {fmt.emoji} {fmt.label}
              </span>
              <span className="text-[10px] font-bold" style={{ color: '#c8956c' }}>
                +{points} pts
              </span>
            </div>
          </div>

          {/* Question / conversation */}
          <div className="px-4 py-4">
            <h3 className="text-sm font-bold text-th-primary leading-snug whitespace-pre-line">
              {currentQuestion.question}
            </h3>
          </div>

          {typing ? (
            /* ── Hard: type the missing word ── */
            <div className="px-4 pb-4">
              {!showResult ? (
                <>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={typedText}
                      onChange={(e) => setTypedText(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleTypedSubmit()}
                      placeholder="Type the missing word…"
                      autoFocus
                      className="flex-1 bg-white/[0.04] border border-white/[0.06] rounded-xl px-3 py-2.5 text-sm text-white placeholder-white/20 focus:outline-none focus:ring-1 focus:ring-[#c8956c]/50"
                    />
                    <motion.button
                      whileTap={{ scale: 0.97 }}
                      onClick={handleTypedSubmit}
                      disabled={!typedText.trim()}
                      className="px-4 py-2.5 btn-primary disabled:bg-white/[0.04] disabled:text-white/20 rounded-xl text-sm font-bold transition-all"
                    >
                      Submit
                    </motion.button>
                  </div>
                  <p className="text-th-muted text-[10px] mt-2">Type the missing word and press Enter.</p>
                </>
              ) : (
                <div className="rounded-xl p-3 bg-white/[0.03] border border-white/[0.06]">
                  <p className="text-th-secondary text-[11px]">You typed:</p>
                  <p className="text-th-primary text-sm font-bold mt-0.5">“{typedAnswer}”</p>
                </div>
              )}
            </div>
          ) : (
            /* ── Easy / Medium: multiple choice ── */
            <div className={`px-4 pb-4 grid gap-2 ${currentQuestion.difficulty === 'medium' ? 'grid-cols-1' : 'grid-cols-2'}`}>
              {currentQuestion.options.map((option, idx) => {
                const isSelected = selectedAnswer === idx;
                const isCorrectAnswer = idx === currentQuestion.correctAnswer;

                let optionStyle = 'bg-white/[0.03] border-white/[0.06] hover:border-[#c8956c]/30 hover:bg-white/[0.06]';
                if (showResult) {
                  if (isCorrectAnswer) {
                    optionStyle = 'bg-[#3d8b4f]/10 border-[#3d8b4f]/40 ring-1 ring-[#3d8b4f]/20';
                  } else if (isSelected && !isCorrectAnswer) {
                    optionStyle = 'bg-[#c43d3d]/10 border-[#c43d3d]/40 ring-1 ring-[#c43d3d]/20';
                  } else {
                    optionStyle = 'bg-white/[0.01] border-white/[0.04] opacity-40';
                  }
                }

                return (
                  <motion.button
                    key={idx}
                    whileHover={!showResult ? { scale: 1.01 } : undefined}
                    whileTap={!showResult ? { scale: 0.99 } : undefined}
                    onClick={() => !showResult && answerQuestion(idx)}
                    disabled={showResult}
                    className={`text-left px-4 py-3 rounded-xl border text-sm font-medium transition-all ${optionStyle}`}
                  >
                    <span className="text-th-secondary">
                      <span className="text-th-muted mr-2">{String.fromCharCode(65 + idx)}.</span>
                      {option}
                    </span>
                    {showResult && isCorrectAnswer && (
                      <span className="ml-2 text-[#3d8b4f]">✓</span>
                    )}
                    {showResult && isSelected && !isCorrectAnswer && (
                      <span className="ml-2 text-[#c43d3d]">✗</span>
                    )}
                  </motion.button>
                );
              })}
            </div>
          )}

          {/* Result feedback */}
          {showResult && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="px-4 pb-4"
            >
              <div className={`rounded-xl p-3 text-center ${isCorrect ? 'bg-[#3d8b4f]/10 border border-[#3d8b4f]/20' : 'bg-[#c43d3d]/10 border border-[#c43d3d]/20'}`}>
                <p className={`font-bold text-sm ${isCorrect ? 'text-[#5aab6f]' : 'text-[#e05555]'}`}>
                  {isCorrect
                    ? `✅ Correct! +${points} pts`
                    : isTraining
                      ? '❌ Incorrect — you stay in this borough'
                      : '❌ Incorrect'}
                </p>
                {typing ? (
                  <p className="text-th-secondary text-[11px] mt-1 leading-relaxed">
                    Accepted answers: <span className="text-th-primary font-bold">{accepted.join(' · ')}</span>
                  </p>
                ) : (
                  !isCorrect && (
                    <p className="text-th-secondary text-[11px] mt-1">
                      The correct answer was: {currentQuestion.options[currentQuestion.correctAnswer]}
                    </p>
                  )
                )}
                {!isCorrect && isTraining && (
                  <p className="text-th-secondary text-[11px] mt-1.5 leading-relaxed">
                    🔒 Answer correctly to move to the next borough — fix the error and try again.
                  </p>
                )}
              </div>
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={nextTurn}
                className="w-full mt-3 py-2.5 btn-primary rounded-xl text-sm font-bold"
              >
                {isTraining && !isCorrect ? '🔄 Try Again' : 'Continue →'}
              </motion.button>
            </motion.div>
          )}
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
