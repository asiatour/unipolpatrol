import { useGameStore } from '../store/gameStore';
import { districts, categoryConfig, categoryList } from '../data/districts';
import { useCustomQuestions } from '../store/useCustomQuestions';
import { motion } from 'framer-motion';

export default function ActionBar() {
  const { currentPlayerIndex, players, phase, beginQuestion } = useGameStore();
  const { customQuestions, deletedIds } = useCustomQuestions();
  const player = players[currentPlayerIndex];

  if (phase === 'setup' || phase === 'gameover' || !player) return null;

  const district = districts.find(d => d.id === player.currentDistrictId);
  const isCompleted = player.routeIndex >= 15;

  // Effective question pool for this borough (built-in + custom)
  const builtIn = district ? district.trivia.filter(q => !deletedIds.includes(q.id)) : [];
  const custom = customQuestions.filter(cq => cq.districtId === player.currentDistrictId);
  const pool = [...builtIn, ...custom.map(cq => cq.question)];
  const hasQuestions = pool.length > 0;

  if (isCompleted) {
    return (
      <div className="glass-card rounded-2xl p-5 text-center">
        <span className="text-2xl">🎖️</span>
        <p className="font-bold text-sm mt-2" style={{ color: '#3d8b4f' }}>{player.name} completed the patrol!</p>
      </div>
    );
  }

  if (phase === 'playing') {
    return (
      <div className="glass-card rounded-2xl p-5 text-center">
        <p className="text-th-muted text-[11px] uppercase tracking-widest font-bold mb-2 font-display">
          {player.name}'s Turn
        </p>
        <div className="flex items-center justify-center gap-2 mb-4">
          <div
            className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold shadow-md"
            style={{ backgroundColor: district?.color === '#FFFFFF' ? '#e8e4df' : district?.color }}
          >
            {district?.icon}
          </div>
          <div className="text-left">
            <p className="text-white font-bold text-sm leading-tight">
              #{player.routeIndex + 1} {district?.name}
            </p>
            {district?.subtitle && (
              <p className="text-th-muted text-[10px]">{district.subtitle}</p>
            )}
          </div>
        </div>

        {!hasQuestions ? (
          <div className="rounded-xl border border-dashed border-white/[0.1] p-4">
            <p className="text-th-secondary text-xs leading-relaxed">
              📝 No questions for this borough yet.<br />
              Open the <span className="text-[#c8956c] font-bold">Questions</span> editor to add custom questions for {district?.name}.
            </p>
          </div>
        ) : (
          <>
            <p className="text-th-secondary text-[11px] mb-4">
              Choose a category for this borough:
            </p>
            <div className="grid grid-cols-2 gap-2">
              {categoryList.map((cat) => {
                const meta = categoryConfig[cat];
                const count = pool.filter(q => q.category === cat).length;
                return (
                  <motion.button
                    key={cat}
                    whileHover={count > 0 ? { scale: 1.03, y: -1 } : undefined}
                    whileTap={count > 0 ? { scale: 0.97 } : undefined}
                    onClick={() => count > 0 && beginQuestion(cat)}
                    disabled={count === 0}
                    className="py-3 rounded-xl text-sm font-bold transition-all flex flex-col items-center gap-1 disabled:opacity-30 disabled:cursor-not-allowed"
                    style={{ backgroundColor: `${meta.color}20`, border: `1px solid ${meta.color}40`, color: meta.color }}
                  >
                    <span className="text-lg leading-none">{meta.emoji}</span>
                    <span className="text-[11px] leading-tight">{meta.label}</span>
                  </motion.button>
                );
              })}
            </div>
          </>
        )}
      </div>
    );
  }

  return null;
}
