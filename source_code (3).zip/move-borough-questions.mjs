// One-off migration: move 10 custom questions from borough 1 -> 2 and
// the next 10 from borough 1 -> 3 (in creation order).
// Uses the public backend API (GET/DELETE/POST /api/public/questions).
// The PUT route can't change district_id, so each row is re-created with the
// same question_id after deletion (question_id has a unique index).
const BASE = 'https://staging--6s8fja7r21gpiv773y9u.youbase.cloud';

async function getAll() {
  const res = await fetch(`${BASE}/api/public/questions`);
  if (!res.ok) throw new Error(`GET failed: ${res.status}`);
  return (await res.json()).data ?? [];
}

function byDistrict(rows) {
  const counts = {};
  for (const r of rows) counts[r.districtId] = (counts[r.districtId] ?? 0) + 1;
  return counts;
}

const before = await getAll();
// Backup snapshot first so a partial failure can always be restored
await import('node:fs').then((fs) => fs.writeFileSync('questions-backup-2.json', JSON.stringify(before, null, 2)));
console.log('Backup saved to questions-backup-2.json');
console.log('Before — total:', before.length, 'by district:', byDistrict(before));

// Borough 1 questions in creation order: first 10 -> district 2, next 10 -> district 3
const fromDistrict1 = before
  .filter((r) => r.districtId === 1)
  .sort((a, b) => (a.createdAt ?? 0) - (b.createdAt ?? 0) || a.id - b.id);

if (fromDistrict1.length < 20) {
  console.log(`ABORT: only ${fromDistrict1.length} questions in borough 1, need 20.`);
  process.exit(1);
}

const plan = [
  ...fromDistrict1.slice(0, 10).map((row) => ({ row, target: 2 })),
  ...fromDistrict1.slice(10, 20).map((row) => ({ row, target: 3 })),
];
console.log(`Moving ${plan.length} questions: 10 -> borough 2, 10 -> borough 3`);

let ok = 0;
const failures = [];
for (const { row, target } of plan) {
  const del = await fetch(`${BASE}/api/public/questions/${encodeURIComponent(row.questionId)}`, { method: 'DELETE' });
  if (!del.ok) {
    failures.push({ id: row.questionId, step: 'delete', status: del.status });
    continue;
  }
  const create = await fetch(`${BASE}/api/public/questions`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      district_id: target,
      question_id: row.questionId,
      question_text: row.questionText,
      option_0: row.option0,
      option_1: row.option1,
      option_2: row.option2,
      option_3: row.option3,
      correct_answer: row.correctAnswer,
      difficulty: row.difficulty,
      category: row.category,
    }),
  });
  if (!create.ok) {
    failures.push({ id: row.questionId, step: 'create', status: create.status, text: await create.text(), row });
    continue;
  }
  ok++;
}

console.log('Moved OK:', ok, '| Failures:', failures.length);
if (failures.length) console.log(JSON.stringify(failures, null, 2));

const after = await getAll();
console.log('After — total:', after.length, 'by district:', byDistrict(after));

// Verify: 20 fewer in district 1, all moved questionIds present at their targets
const stillIn1 = after.filter((r) => r.districtId === 1).length;
const missing = plan.filter(({ row, target }) => !after.some((a) => a.questionId === row.questionId && a.districtId === target));
const extras = after.length !== before.length ? `TOTAL CHANGED (${before.length} -> ${after.length})` : 'total unchanged';
console.log(`Borough 1 now has ${stillIn1} (was ${fromDistrict1.length}) | Missing at target: ${missing.length} | ${extras}`);
if (missing.length) console.log(JSON.stringify(missing.map((m) => m.row.questionId)));
